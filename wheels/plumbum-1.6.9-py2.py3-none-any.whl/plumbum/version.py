version = (1, 6, 9)
version_string = ".".join(map(str, version))
release_date = "2020.03.23"
