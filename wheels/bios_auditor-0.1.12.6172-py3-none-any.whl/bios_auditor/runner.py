"""Module to execute tests on Bios Settings"""

# TODO:  Move tests into Class Format for DRY code

# pylint: disable=possibly-unused-variable
# This disable is for the function within a function for bounds testing 1 statement vs 6

# Stander Library Imports
import logging

# Local Library Imports
from bios_auditor.bios_interface import get_interface

INTERFACE = None


def initialize_interface(configuration):
    """

    Args:
        configuration:
    """
    # pylint: disable=global-statement
    global INTERFACE
    INTERFACE = get_interface(configuration)


class AttributeTester:
    """
    Class to hold test information for each Bios Setting
    """
    tests = {'HPBIOS_BIOSInteger': ['bounds', 'int_audit_reg', 'value_default'],
             'HPBIOS_BIOSOrderedList': ['ord_audit_reg'],
             'HPBIOS_BIOSPassword': ['str_bounds', 'psw_audit_reg'],
             'HPBIOS_BIOSString': ['str_bounds', 'str_audit_reg', 'value_default'],
             'HPBIOS_BIOSEnumeration': ['enu_audit_reg', 'value_default']}

    def __init__(self, data, initialize=False):

        if initialize:
            data_type = data['attributes']['Oem']['Class']['Value']
            self.state = {'reg': data['attributes'],
                          'test_list': self.tests[data_type].copy(),
                          'call_no': 0,
                          'setting_name': data['attributes']['AttributeName'],
                          'outcome': 'in_progress',
                          'locked': False,
                          'errors': []}
        else:
            self.state = data

        self.attr = INTERFACE.get_attributes(self.state['reg']['DisplayName'])

    def run(self):
        """

        Returns:

        """
        self.state['call_no'] += 1

        for test in self.state['test_list']:
            # Executes the test_function still in test_list
            getattr(AttributeTester, test)(self)

        if not self.state['test_list']:
            if not self.state['errors']:
                self.state['outcome'] = 'succeeded'
            else:
                self.state['outcome'] = 'failed'

        return self.state

    def _audit_reg(self):
        """

        Returns:

        """
        actual = self.attr
        expected = self.state['reg']
        error_report = []

        to_test = ['DisplayName',
                   'MenuPath',
                   'Hidden',
                   'DisplayOrder',
                   'AttributeName',
                   'ReadOnly']  # , Commented out till preprocessor allows for this dict key
        # 'Oem.RequiresPhysicalPresence.Value',
        # 'Oem.SecurityLevel.Value',
        # 'Oem.Prerequisites.Value']

        for meta_data in to_test:
            if actual[meta_data] != expected[meta_data]:
                error_report.append((meta_data, expected[meta_data], actual[meta_data]))

        if actual['Oem']['RequiresPhysicalPresence']['Value'] != \
                expected['Oem']['RequiresPhysicalPresence']['Value']:
            error_report.append(('Oem.RequiresPhysicalPresence.Value',
                                 expected['Oem']['RequiresPhysicalPresence']['Value'],
                                 actual['Oem']['RequiresPhysicalPresence']['Value']))

        if actual['Oem']['SecurityLevel']['Value'] != expected['Oem']['SecurityLevel']['Value']:
            error_report.append(('Oem.SecurityLevel.Value',
                                 expected['Oem']['SecurityLevel']['Value'],
                                 actual['Oem']['SecurityLevel']['Value']))

        if actual['Oem']['Prerequisites']['Value'] != expected['Oem']['Prerequisites']['Value']:
            error_report.append(('Oem.Prerequisites.Value',
                                 expected['Oem']['Prerequisites']['Value'],
                                 actual['Oem']['Prerequisites']['Value']))

        return error_report

    def int_audit_reg(self):
        """
        Tests specific integer metadata
        """
        logging.info(f'int_audit_reg test Started: {self.state["setting_name"]}')

        error_report = self._audit_reg()

        to_test = ['Type',
                   'LowerBound',
                   'UpperBound']

        for meta_data in to_test:
            if self.attr[meta_data] != self.state['reg'][meta_data]:
                error_report.append((meta_data, self.state['reg'][meta_data], self.attr[meta_data]))

        self.state['errors'].extend(error_report)
        self.state['test_list'].remove('int_audit_reg')
        logging.info(f'int_audit_reg test Ended: {self.state["setting_name"]}')

    def str_audit_reg(self):
        """
        Tests specific string metadata
        """
        logging.info(f'str_audit_reg test Started: {self.state["setting_name"]}')

        error_report = self._audit_reg()

        to_test = ['Type',
                   'MinLength',
                   'MaxLength']

        for meta_data in to_test:
            if self.attr[meta_data] != self.state['reg'][meta_data]:
                error_report.append((meta_data, self.state['reg'][meta_data], self.attr[meta_data]))

        self.state['errors'].extend(error_report)
        self.state['test_list'].remove('str_audit_reg')
        logging.info(f'str_audit_reg test Ended: {self.state["setting_name"]}')

    def enu_audit_reg(self):
        """
        Tests Specific enumeration metadata
        """
        logging.info(f'enu_audit_reg test Started: {self.state["setting_name"]}')

        error_report = self._audit_reg()

        to_test = ['Type',
                   'Value']

        for meta_data in to_test:
            if self.attr[meta_data] != self.state['reg'][meta_data]:
                error_report.append((meta_data, self.state['reg'][meta_data], self.attr[meta_data]))

        self.state['errors'].extend(error_report)
        self.state['test_list'].remove('enu_audit_reg')
        logging.info(f'enu_audit_reg test Ended: {self.state["setting_name"]}')

    def ord_audit_reg(self):
        """
        Tests Specific Ordered Lists metadata
        """
        logging.info(f'ord_audit_reg test Started: {self.state["setting_name"]}')

        error_report = self._audit_reg()

        # All that was in the redfish, but looks like the actual registry
        if self.attr['Oem']['ExtendedType']['Value'] != \
                self.state['reg']['Oem']['ExtendedType']['Value']:
            error_report.append(('Oem.ExtendedType.Value',
                                 self.state['reg']['Oem']['ExtendedType']['Value'],
                                 self.attr['Oem']['ExtendedType']['Value']))

        if self.attr['Oem']['Summary']['Value'] != self.state['reg']['Oem']['Summary']['Value']:
            error_report.append(('Oem.Summary.Value',
                                 self.state['reg']['Oem']['Summary']['Value'],
                                 self.attr['Oem']['Summary']['Value']))

        self.state['errors'].extend(error_report)
        self.state['test_list'].remove('ord_audit_reg')
        logging.info(f'ord_audit_reg test Ended: {self.state["setting_name"]}')

    def psw_audit_reg(self):
        """
        Tests Specific Password metadata
        """
        logging.info(f'psw_audit_reg test Started: {self.state["setting_name"]}')

        error_report = self._audit_reg()

        to_test = ['Type',
                   'MinLength',
                   'MaxLength']

        for meta_data in to_test:
            if self.attr[meta_data] != self.state['reg'][meta_data]:
                error_report.append((meta_data, self.state['reg'][meta_data], self.attr[meta_data]))

        if self.attr['Oem']['SupportedEncoding']['Value'] != \
                self.state['reg']['Oem']['SupportedEncoding']['Value']:
            error_report.append(('Oem.SupportedEncoding.Value',
                                 self.state['reg']['Oem']['SupportedEncoding']['Value'],
                                 self.attr['Oem']['SupportedEncoding']['Value']))

        self.state['errors'].extend(error_report)
        self.state['test_list'].remove('psw_audit_reg')
        logging.info(f'psw_audit_reg test Ended: {self.state["setting_name"]}')

    def value_default(self):
        """

        Returns:

        """
        # Set up its saved state
        if 'value_default' not in self.state:
            stored_data = {'call_no': 1,
                           'active': False}
            self.state['value_default'] = stored_data

        else:
            stored_data = self.state['value_default']

        if self.state['locked'] and not stored_data['active']:
            return
        print('value_default test')

        self.state['locked'] = True
        stored_data['active'] = True

        error_report = []
        if 'CurrentValue' not in self.attr:
            error_report.append(('default reg test',
                                 f'{self.state["reg"]["DefaultValue"]}',
                                 'N/A'))

        elif self.attr['CurrentValue'] != self.state['reg']['DefaultValue']:
            error_report.append(('default reg test',
                                 f'{self.state["reg"]["DefaultValue"]}',
                                 f'{self.attr["CurrentValue"]}'))

        self.state['test_list'].remove('value_default')
        self.state['errors'].extend(error_report)
        self.state['locked'] = False
        stored_data['active'] = False

    def bounds(self):
        """

        Returns:

        """
        # Set up its saved state
        if 'bounds' not in self.state:
            stored_data = {'call_no': 1,
                           'active': False,
                           'error_report': []}
            self.state['bounds'] = stored_data

        else:
            stored_data = self.state['bounds']

        if self.state['locked'] and not stored_data['active']:
            return
        self.state['locked'] = True
        stored_data['active'] = True

        print('Bounds test active')
        upper_bound = self.state['reg']['UpperBound']
        lower_bound = self.state['reg']['LowerBound']

        def call_1():
            print('inside call 1')
            # Get Original value(OG) and store
            stored_data['OG_value'] = INTERFACE.get_value(self.attr['DisplayName'])

            # Test upper bound +1
            result = INTERFACE.set_value(self.attr['DisplayName'], upper_bound + 1)
            if result == 0:
                stored_data['error_report'].append(('upperbound limit +1',
                                                    'FAILED',
                                                    'PASSED'))

            # Test lower bound -1
            result = INTERFACE.set_value(self.attr['DisplayName'], lower_bound - 1)
            if result == 0:
                stored_data['error_report'].append(('lowerbound limit -1',
                                                    'FAILED',
                                                    'PASSED'))

            # set UpperBound
            result = INTERFACE.set_value(self.attr['DisplayName'], upper_bound)
            if result != 0:
                stored_data['error_report'].append(('Could not set Upper_bound',
                                                    'PASSED',
                                                    'FAILED'))

        def call_2():
            print('inside call 2')
            # Confirm Upper Bound
            curr_value = INTERFACE.get_value(self.attr['DisplayName'])
            if int(curr_value) != upper_bound:
                stored_data['error_report'].append(('Upper_bound failed to set',
                                                    upper_bound,
                                                    curr_value))

            # set LowerBound
            result = INTERFACE.set_value(self.attr['DisplayName'], lower_bound)
            if result != 0:
                stored_data['error_report'].append(('Could not set lower_bound',
                                                    'PASSED',
                                                    'FAILED'))

        def call_3():
            print('inside call 3')
            # Confirm LowerBound
            curr_value = INTERFACE.get_value(self.attr['DisplayName'])
            if int(curr_value) != lower_bound:
                stored_data['error_report'].append(('lower_bound failed to set',
                                                    upper_bound,
                                                    curr_value))

            # Set Value back to OG
            result = INTERFACE.set_value(self.attr['DisplayName'], stored_data['OG_value'])
            if result != 0:
                curr_value = INTERFACE.get_value(self.attr['DisplayName'])
                stored_data['error_report'].append(('Could not set back to original value',
                                                    curr_value,
                                                    stored_data['OG_value']))

            # Remove Test from test_list
            self.state['errors'].extend(stored_data['error_report'])
            self.state['test_list'].remove('bounds')
            self.state['locked'] = False
            stored_data['active'] = False

        locals()['call_' + str(stored_data['call_no'])]()

        stored_data['call_no'] += 1
        self.state['bounds'] = stored_data

    def str_bounds(self):
        # pylint: disable=too-many-statements
        """

        Returns:

        """
        # Set up its saved state
        if 'str_bounds' not in self.state:
            stored_data = {'call_no': 1,
                           'active': False,
                           'error_report': []}
            self.state['str_bounds'] = stored_data

        else:
            stored_data = self.state['str_bounds']

        if self.state['locked'] and not stored_data['active']:
            return
        self.state['locked'] = True
        stored_data['active'] = True

        print('str_bounds test active')

        lower_bound = self.state['reg']['MinLength']
        upper_bound = self.state['reg']['MaxLength']

        def call_1():
            print('inside call 1')
            # Get Original value(OG) and store
            stored_data['OG_value'] = INTERFACE.get_value(self.attr['DisplayName'])

            # Test upper bound +1
            over_upper = 'a' * (upper_bound + 1)
            result = INTERFACE.set_value(self.attr['DisplayName'], over_upper)
            if result == 0:
                stored_data['error_report'].append(('MaxLength +1',
                                                    'FAILED',
                                                    'PASSED'))

            # Test lower bound -1
            under_lower = 'a' * (lower_bound - 1)
            if under_lower:
                result = INTERFACE.set_value(self.attr['DisplayName'], under_lower)
                if result == 0:
                    stored_data['error_report'].append(('MinLength -1',
                                                        'FAILED',
                                                        'PASSED'))

            # set UpperBound
            upper_correct = 'a' * upper_bound
            result = INTERFACE.set_value(self.attr['DisplayName'], upper_correct)
            if result != 0:
                stored_data['error_report'].append(('Could not set MaxLength',
                                                    'PASSED',
                                                    'FAILED'))

        def call_2():
            print('inside call 2')
            # Confirm Upper Bound
            upper_correct = 'a' * upper_bound
            curr_value = INTERFACE.get_value(self.attr['DisplayName'])
            if curr_value != upper_correct:
                stored_data['error_report'].append(('MaxLangth failed to set',
                                                    upper_bound,
                                                    curr_value))

            # set LowerBound
            lower_correct = 'a' * lower_bound
            result = INTERFACE.set_value(self.attr['DisplayName'], lower_correct)
            if result != 0:
                stored_data['error_report'].append(('Could not set MinLength',
                                                    'PASSED',
                                                    'FAILED'))

        def call_3():
            print('inside call 3')
            # Confirm LowerBound
            lower_correct = 'a' * lower_bound
            curr_value = INTERFACE.get_value(self.attr['DisplayName'])
            if curr_value != lower_correct:
                stored_data['error_report'].append(('MinLength failed to set',
                                                    lower_bound,
                                                    curr_value))

            # Set Value back to OG
            result = INTERFACE.set_value(self.attr['DisplayName'], stored_data['OG_value'])
            if result != 0:
                curr_value = INTERFACE.get_value(self.attr['DisplayName'])
                stored_data['error_report'].append(('Could not set back to original value',
                                                    curr_value,
                                                    stored_data['OG_value']))

            # Remove Test from test_list
            self.state['errors'].extend(stored_data['error_report'])
            self.state['test_list'].remove('str_bounds')
            self.state['locked'] = False
            stored_data['active'] = False

        locals()['call_' + str(stored_data['call_no'])]()

        stored_data['call_no'] += 1
        self.state['str_bounds'] = stored_data
