"""Set the schedule to follow for running tests, and execute calls to the test
runner based on the schedule.
"""
# Standard-library imports
from copy import copy

# Third-party imports
import hp_logging.logger as logger

# Local-library imports
from bios_auditor.runner import AttributeTester, initialize_interface


def run_tests(auditor_state):
    """Run tests based on the current auditor state."""

    initialize_interface(auditor_state.configuration)

    # The two main loops in this function iterate over setting names stored
    # in auditor_state, making changes in auditor_state inside the loops.  In
    # order to avoid changing an object while iterating over it, we create lists
    # to iterate over before executing the loops.  These lists are copies and so
    # are not changed when auditor_state is changed.

    settings_in_progress = list(auditor_state.in_progress.keys())
    settings_not_started = copy(auditor_state.not_started)

    for name in settings_in_progress:
        # Extract the saved test data.
        test_data = auditor_state.in_progress[name]
        # Continue the test, receiving updated test data.
        test_data = call_runner(name, test_data, initialize=False)
        auditor_state = store_test_data(test_data, auditor_state)

    for name in settings_not_started:
        # Change the status of the setting from not_started to in_progress.
        auditor_state.not_started.remove(name)
        # The dictionary auditor_state.in_progress has setting names as keys.
        # The corresponding value is the saved state of the test(s) for the
        # setting.  Initially this is set to None.
        auditor_state.in_progress[name] = None

        # Extract the registry data for the setting.
        registry_data = auditor_state.registry[name]
        # Start the test, using the registry data for initialization.
        test_data = call_runner(name, registry_data, initialize=True)
        auditor_state = store_test_data(test_data, auditor_state)

    return auditor_state


def call_runner(name, data, initialize):
    """Call the test runner."""
    input_data = data
    try:
        test_runner = AttributeTester(data, initialize)
        data = test_runner.run()
    except logger.ReportedError:
        data = get_crash_data(name, input_data, initialize)
    except Exception as ex:
        data = get_crash_data(name, input_data, initialize)
        data['caught_exception'] = ex
        message = (
            f'A test of setting {name} crashed.'
        )
        dev_log_message = message + '\n'
        message_to_user = message + '  See "auditor.log" for details.\n'
        logger.print_alert(dev_log_message, message_to_user, caught_exception=ex)
    return data


def get_crash_data(name, input_data, initialize):
    """Create a dictionary of data that can be saved in
    auditor_stated.crashed."""
    test_data = {'setting_name': name,
                 'outcome': 'crashed',
                 'initial_run': initialize,
                 'input_data': input_data}
    return test_data


def store_test_data(test_data, auditor_state):
    """Store test data in the auditor_state object."""
    name = test_data['setting_name']
    outcome = test_data['outcome']

    stored_data = getattr(auditor_state, outcome)
    stored_data[name] = test_data

    # Remove the setting name from the in_progress dictionary in a way
    # that raises an exception if the name is not found as a key.  We
    # want an exception if things are not working as expected.
    if outcome != 'in_progress':
        del auditor_state.in_progress[name]

    return auditor_state
