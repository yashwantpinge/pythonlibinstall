"""Define a base class that knows how to save itself to disk and also reload
itself given a filename passed to the constructor."""

# Standard-library imports
from pathlib import Path
import pickle

# Third-party imports
import hp_logging.logger as logger


class Reloadable:
    """Base class that knows how to save itself to disk and also reload
    itself given a filename passed to the constructor.

    The save method saves self.__dict__ to a pickle file, and the load method
    loads a pickled file and sets self.__dict__ to the contents.

    If the 'load' argument to the constructor is True and the 'file_path'
    argument is not empty, the constructor calls self.load, i.e., the
    constructor reconstructs the Reloadable object state at the time self.save
    was last called.
    """

    # pylint: disable=too-many-instance-attributes

    def __init__(self, file_path=None, load=False):

        if load and not file_path:
            log_message = (
                'In the constructor for Reloadable, a filename must be given '
                'if "load" is True.\n'
            )
            message_to_user = (
                'Unable to load the saved state without a filename.\n'
            )
            logger.print_alert_and_raise(dev_log_message=log_message,
                                         message_to_user=message_to_user)

        self.file_path = file_path
        if load:
            self.load()

    def load(self):
        """Load the object attributes from a pickle file.

        Note that the path to the pickle file should be stored in
        self.file_path.
        """

        self.check_for_file_path()
        if not Path(self.file_path).is_file():
            log_message = (
                'In the class Reloadable, the pickle file cannot be loaded '
                f'because\n{self.file_path}\nis not a file.\n'
            )
            message_to_user = (
                'Unable to load the saved state because\n'
                f'{self.file_path}\nis not a file.\n'
            )
            logger.print_alert_and_raise(dev_log_message=log_message,
                                         message_to_user=message_to_user)

        with open(self.file_path, 'rb') as serialized_object:
            file_path = self.file_path
            self.__dict__ = pickle.load(serialized_object)
            self.file_path = file_path

        logger.info(f'Loaded attributes from {self.file_path}')

    def save(self):
        """Save the object attributes to a pickle file, returning self."""

        self.check_for_file_path()

        with open(self.file_path, 'wb') as serialized_object:
            pickle.dump(self.__dict__, serialized_object,
                        pickle.HIGHEST_PROTOCOL)

        logger.info(f'Saved attributes to {self.file_path}')
        return self

    def check_for_file_path(self):
        """Check whether self.file_path has been defined before attempting to
        load attributes from a pickle file."""
        if not self.file_path:
            log_message = (
                'In the class Reloadable, the pickle file cannot be loaded '
                'because the filename is not defined.\n'
            )
            message_to_user = (
                'Unable to load the saved state without a filename.\n'
            )
            logger.print_alert_and_raise(dev_log_message=log_message,
                                         message_to_user=message_to_user)
