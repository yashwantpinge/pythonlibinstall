"""Public API for the bios_auditor package

Keywords for bios_auditor in robot framework correspond to functions in the
current module.
"""
# Standard-library imports
from pathlib import Path

# Local-library imports
import bios_auditor.auditor as auditor
import bios_auditor.reporter as reporter


main_args_no_load = ['--workspace',
                     '.',
                     '--input-file',
                     'simple_settings.txt',
                     '--registry-file',
                     'simple_registry.json',
                     '--initialize',
                     '--configuration',
                     'wmi']
main_args_load = ['--workspace',
                  '.',
                  '--input-file',
                  'simple_settings.txt',
                  '--registry-file',
                  'simple_registry.json',
                  '--configuration',
                  'wmi']


def run_basic(load_state=True,
              workspace=None):
    """Run basic test designed for demo."""
    cur = ['--workspace', workspace]
    main_args_load.extend(cur)
    main_args_no_load.extend(cur)

    auditor_state = _call_auditor(load_state)

    # Done testing
    if not auditor_state.in_progress:
        _gen_report(auditor_state, title='Demo of bios-auditor')
        return 1

    # Continue testing
    return 0


def run_robot():
    """RF Keyword implementation specifically for Vcosmos"""
    log_path = Path.cwd() / 'LOGS'
    log_arg = ['--log-file-path', str(log_path / 'auditor.txt')]
    main_args_load.extend(log_arg)
    main_args_no_load.extend(log_arg)

    run_state = Path('running.txt')
    if not run_state.exists():
        load_state = False
        run_state.write_text('running')
    else:
        load_state = True

    auditor_state = _call_auditor(load_state)

    if not auditor_state.status_ok:
        raise RuntimeError('Auditor Failed...check logs')

    if not auditor_state.in_progress:
        _gen_report(auditor_state, file_path=log_path)
        run_state.unlink()
        return 'done'

    return 'in progress'


def _call_auditor(load_state):
    if load_state:
        auditor_state = auditor.main(main_args_load)
    else:
        auditor_state = auditor.main(main_args_no_load)

    return auditor_state


def _gen_report(auditor_state,
                filename='Bios_Auditor_Report',
                title='Bios-Auditor',
                file_path=None):
    """

    Args:
        auditor_state:
        filename:
        title:
        file_path:
    """
    reporter.log_report_to_robot(
        succeeded=auditor_state.succeeded,
        failed=auditor_state.failed,
        crashed=auditor_state.crashed
    )
    report = reporter.generate_html_report(
        title,
        succeeded=auditor_state.succeeded,
        failed=auditor_state.failed,
        crashed=auditor_state.crashed
    )
    if not file_path:
        Path(f'{filename}.html').write_text(report)
    else:
        (file_path / f'{filename}.html').write_text(report)
