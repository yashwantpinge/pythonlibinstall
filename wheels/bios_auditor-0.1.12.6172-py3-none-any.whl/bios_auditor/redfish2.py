"""Convert WMI BIOS metadata to Redfish format."""

# TODO:  This module should be moved into the redfish repo.

import re

# pylint: disable=invalid-name


def _import_base_class_attributes(setting, attributes):
    """Import the attributes that are defined for the base WMI class
    HP_BIOSSetting

    Returns:
        Dictionary corresponding to Attributes in Redfish schema.  This
        dictionary contains entries for all properties defined for
        HP_BIOSSetting.
    """
    print(setting.Name)
    attributes['DisplayName'] = setting.Name
    menu_path = '.' + setting.Path.replace('\\', '/')
    # The command above gave '.' as the menu_path- for some settings, which
    # violates the Redfish pattern '^\\.\\/([^/]+(\\/[^/]+)*)?$'
    # The next line corrects this problem.
    if menu_path == '.':
        menu_path += '/'
    attributes['MenuPath'] = menu_path
    attributes['ReadOnly'] = bool(setting.IsReadOnly)
    attributes['Hidden'] = not bool(setting.DisplayInUI)
    attributes['DisplayOrder'] = setting.Sequence

    # These have no Redfish counterpart, so they are added as part of the OEM
    # Redfish property.
    attributes['Oem'] = {}
    attributes['Oem']['RequiresPhysicalPresence'] = {
        'Value': bool(setting.RequiresPhysicalPresence)
    }
    attributes['Oem']['SecurityLevel'] = {'Value': setting.SecurityLevel}
    attributes['Oem']['Summary'] = {'Value': setting.Value}
    attributes['Oem']['Prerequisites'] = {'Value': setting.Prerequisites}

    # The schema is violated if we define AttributeName to be None, or if we
    # define AttributeName to equal DisplayName, since the required pattern
    # for AttributeName is '^[A-Za-z][A-Za-z0-9_]+$'
    #
    # For now, any characters not corresponding to this regex are replaced by  _
    cleaned_display_name = re.sub('[^A-Za-z0-9_]', '_',
                                  attributes['DisplayName'])
    attributes['AttributeName'] = cleaned_display_name

    return attributes


def filter_value(wmi_value, make_registry):
    """Return an attribute that is null for a registry.

    If a registry is being generated, return None; otherwise, return the wmi
    value passed as an argument.
    determined by the arguments.
    """
    if make_registry:
        return None

    return wmi_value


def _import_BIOSString(setting, attributes, make_registry):

    attributes['Type'] = 'String'
    attributes['MinLength'] = setting.MinLength
    attributes['MaxLength'] = setting.MaxLength
    _import_current_value(setting.Value, attributes, make_registry)

    return attributes


def _import_BIOSInteger(setting, attributes, make_registry):

    attributes['Type'] = 'Integer'
    attributes['LowerBound'] = setting.LowerBound
    attributes['UpperBound'] = setting.UpperBound
    _import_current_value(setting.IntValue, attributes, make_registry)

    return attributes


def _import_BIOSEnumeration(setting, attributes, make_registry):

    attributes['Type'] = 'Enumeration'
    attributes['Value'] = []
    for enum_element in setting.PossibleValues:
        attributes['Value'].append({'ValueName': enum_element})
    _import_current_value(setting.CurrentValue, attributes, make_registry)

    return attributes


def _import_BIOSOrderedList(setting, attributes, make_registry):

    # There is no AttributeType in AttributeRegistry corresponding to an array
    # or list.  The schema is violated if we set 'Type' to anything other than
    # one of the enumerated values for AttributeType, and so we exclude this
    # property.
    #attributes['Type'] = None

    # Note that the schema is violated if we use 'Type' in 'Oem' that does not
    # match one of the values in AttributeType, so for OrderedList, we add a
    # property 'ExtendedType'.
    attributes['Oem']['ExtendedType'] = {'Value': 'Array'}
    attributes['Oem']['OrderedListElements'] = {
        'Value': filter_value(setting.Elements, make_registry)
    }

    return attributes


def _import_BIOSPassword(setting, attributes, make_registry):

    attributes['Type'] = 'Password'
    attributes['MinLength'] = setting.MinLength
    attributes['MaxLength'] = setting.MaxLength
    # Note that setting.SupportedEncoding is a tuple of strings.
    attributes['Oem']['SupportedEncoding'] = {'Value': setting.SupportedEncoding}
    attributes['Oem']['IsSet'] = {'Value': filter_value(bool(setting.IsSet), make_registry)}

    return attributes


def _import_current_value(current_wmi_value, redfish_attributes, make_registry):
    """Set CurrentValue or DefaultValue, depending on whether a registry is
    being generated.
    """
    if make_registry:
        redfish_attributes['DefaultValue'] = current_wmi_value
    else:
        redfish_attributes['CurrentValue'] = current_wmi_value


_IMPORT_FUNCTIONS = {'HPBIOS_BIOSString': _import_BIOSString,
                     'HPBIOS_BIOSInteger': _import_BIOSInteger,
                     'HPBIOS_BIOSEnumeration': _import_BIOSEnumeration,
                     'HPBIOS_BIOSOrderedList': _import_BIOSOrderedList,
                     'HPBIOS_BIOSPassword': _import_BIOSPassword}


def wmi_to_redfish(wmi_object):
    """Convert the metadata for a WMI BIOS setting to Redfish format."""
    make_registry = False
    attributes = _import_base_class_attributes(wmi_object, {})
    setting_class = wmi_object.Path_.Class
    attributes['Oem']['Class'] = {'Value': setting_class}
    import_function = _IMPORT_FUNCTIONS[setting_class]
    attributes = import_function(wmi_object, attributes, make_registry)

    return attributes
