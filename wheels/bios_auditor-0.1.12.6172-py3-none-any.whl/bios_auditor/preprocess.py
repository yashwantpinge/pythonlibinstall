"""Preprocess registry to simplify use by the BIOS auditor"""


def process_registry(raw_registry, settings_to_test):
    """Extract information from the registry in a format convenient for
    testing by the BIOS auditor

    The function returns a dictionary with the names of settings for keys.  The
    corresponding value should include all information needed to perform a
    suite of tests for the setting.
    """
    #  For now, we just set the dependencies to by an empty list.

    attributes_list = raw_registry['RegistryEntries']['Attributes']

    # Make a dictionary that has (key, value) pairs of the form
    #
    # (setting_name, index of setting in attributes_list)
    #
    # It's just too ugly to be searching the full list of attributes each time
    # we try to find information about a particular setting.
    setting_finder = [(setting['AttributeName'], index)
                      for (index, setting) in enumerate(attributes_list)
                      if 'AttributeName' in setting and setting['AttributeName']]
    setting_finder = dict(setting_finder)

    processed_registry = {}
    for setting_name in settings_to_test:
        if setting_name not in setting_finder:
            raise ValueError(f'Setting {setting_name} not found in the registry')
        index = setting_finder[setting_name]

        data = {'attributes': attributes_list[index],
                'dependencies': []}
        processed_registry[setting_name] = data

    return processed_registry

# TODO:  Either delete the commented-out code or incorporate it into the module.
# def flesh_out_reg(d):
#
#     for x in list(d):
#         try:
#             if type(d[x]) is dict:
#                 for a in d[x]:
#                     d[f"{x}.{a}"] = d[x][a]
#                     d.update(flesh_out_reg(d[f"{x}.{a}"]))
#         except:
#             pass
#
#     return d
#
#
# if __name__ == '__main__':
#     test_truth_reg = {
#         "AttributeName": "Data_transfer_timeout",
#         "CurrentValue": None,
#         "DefaultValue": 100,
#         "DisplayName": "Data transfer timeout",
#         "DisplayOrder": 27855,
#         "GrayOut": None,
#         "HelpText": None,
#         "Hidden": False,
#         "Immutable": None,
#         "IsSystemUniqueProperty": None,
#         "LowerBound": 1,
#         "MenuPath": "./Advanced/Configurations",
#         "Oem": {
#             "Class": {
#                 "Value": "HPBIOS_BIOSInteger"
#             },
#             "Prerequisites": {
#                 "Value": None
#             },
#             "RequiresPhysicalPresence": {
#                 "Value": False
#             },
#             "SecurityLevel": {
#                 "Value": 0
#             },
#             "Summary": {
#                 "Value": "100"
#             }
#         },
#         "ReadOnly": False,
#         "ResetRequired": None,
#         "Type": "Integer",
#         "UpperBound": 65535,
#         "ValueExpression": None,
#         "WarningText": None,
#         "WriteOnly": None
#     }
#       Runnin it twice gets right results...kinda
#     flesh_out_reg(test_truth_reg)
#     flesh_out_reg(test_truth_reg)
#     pprint(test_truth_reg)
