"""Class-based interface to BIOS settings"""

from bios_auditor.redfish2 import wmi_to_redfish

# pylint: disable=super-init-not-called


def get_interface(configuration=None):
    """Return an instance of the class Bios or a derived class.

    The configuration argument is used to select the class.
    """
    # TODO:  Check whether configuration is recognized, handle the case where it is not.
    if configuration == 'wmi':
        return WMIBios()
    if configuration == 'ovmf':
        return OVMFBios()

    return Bios()


class Bios:
    """Base class for BIOS interface with no functionality implemented."""

    def __init__(self):
        pass

    def set_value(self, name, value):
        """Set the value of a BIOS setting."""

    def get_value(self, name):
        """Get the value of a BIOS setting."""

    def get_attributes(self, name):
        """Get a dictionary of attributes for a BIOS setting in Redfish format."""


class WMIBios(Bios):
    """WMI-based interface to BIOS."""

    def __init__(self):
        from hp_wmi import public_wmi  # pylint: disable=import-outside-toplevel
        # Not working.............
        # from bios_auditor.redfish2 import wmi_to_redfish
        self.wmi = public_wmi.BiosSettings()
        self.wmi_settings = self.wmi.get_all_settings()

    def set_value(self, name, value):
        return self.wmi.set_value(name, value)

    def get_value(self, name):
        return self.wmi.get_value(name)

    def get_attributes(self, name):
        for setting in self.wmi_settings:
            if setting.Name == name:
                return wmi_to_redfish(setting)
        return None


# TODO: Define OVMF_Bios class
class OVMFBios(Bios):
    """OVMF-based interface to BIOS."""

    def __init__(self):
        pass

    def set_value(self, name, value):
        pass

    def get_value(self, name):
        pass

    def get_attributes(self, name):
        pass
