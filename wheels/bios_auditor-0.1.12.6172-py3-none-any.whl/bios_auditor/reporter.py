"""Generate an html report summarizing test results."""

import hp_logging.html as html
import hp_logging.logger as hp_logger


def get_robot_logger():
    """Get the robot.api.logger module."""
    # pylint: disable=import-outside-toplevel
    import robot.api.logger as robot_logger
    return robot_logger


def log_report_to_robot(succeeded, failed, crashed):
    """Add a summary of the test results to the robot framework log.

    The requirements for arguments succeeded, failed, and crashed are
    explained in the docstring for the function generate_html_report.
    """
    robot_logger = get_robot_logger()

    crashed_table = format_crashed(crashed)
    if crashed_table['html']:
        robot_logger.info(crashed_table['html'], html=True)

    failed_table = format_failed(failed)
    if failed_table['html']:
        robot_logger.info(failed_table['html'], html=True)

    succeeded_table = format_succeeded(succeeded)
    if succeeded_table['html']:
        robot_logger.info(succeeded_table['html'], html=True)

    tested_names = sorted(list(set(failed_table['setting_names']
                                   + succeeded_table['setting_names']
                                   + crashed_table['setting_names'])))

    # Handle the special case where no settings were tested.
    if not tested_names:
        robot_logger.info('No settings were tested')
        return

    summary = 'Settings tested'
    html_message = html.get_expandable_table(
        summary, tested_names, color_scheme=None
    )
    robot_logger.info(html_message, html=True)

    number_tested = len(tested_names)
    setting_or_settings = add_s_if_plural('setting', number_tested)
    robot_logger.info(f'{len(tested_names)} {setting_or_settings} tested')

    number_crashed = len(crashed_table['table_rows'])
    if number_crashed:
        test_or_tests = add_s_if_plural('test', number_crashed)
        robot_logger.info(f'{number_crashed} {test_or_tests} crashed')

    number_failed = len(failed_table['table_rows'])
    if number_failed:
        test_or_tests = add_s_if_plural('test', number_failed)
        robot_logger.info(f'{number_failed} {test_or_tests} failed')

    if not number_failed + number_crashed:
        robot_logger.info('All tests passed')

    hp_logger.info('Summary of test results added to robot framework html log.')


def add_s_if_plural(word, number):
    """Add 's' to a word in a log if the number argument is plural."""
    if number > 1:
        return word + 's'

    return word


def generate_html_report(title, succeeded, failed, crashed):
    """Generate an html report summarizing the test results.

    The arguments succeeded, failed, crashed are dictionaries containing
    setting names as keys.

    If any test failed for a particular setting, then that setting name should
    be a key in the failed dictionary.  For example, if 'setting_a' did not
    pass all tests, then

    failed['setting_a']

    should be a dictionary of test data.  In particular,

    failed['setting_a']['errors']

    should be a list of 3-tuples:

    (test name that failed, expected value, actual value)


    Args:
        title:  The title of the report.

        succeeded:  Dictionary of test data for settings that passed all
            tests.

        failed:  Dictionary of test data for settings that had one or more
            failed tests.

        crashed:  Dictionary of data for settings that caused an exception to
            be raised during testing.

    Returns:
        An html report (in the form of a string) summarizing the test results.

    """
    # pylint: disable=too-many-locals
    page_html = html.get_starting_html(title)
    page_html += html.get_heading(title, 'h2')

    crashed_table = format_crashed(crashed)
    if crashed_table['html']:
        page_html += html.add_indicator_box('info', crashed_table['html']) + '\n'

    failed_table = format_failed(failed)
    if failed_table['html']:
        page_html += html.add_indicator_box('info', failed_table['html']) + '\n'

    succeeded_table = format_succeeded(succeeded)
    if succeeded_table['html']:
        page_html += html.add_indicator_box('info', succeeded_table['html']) + '\n'

    tested_names = sorted(list(set(failed_table['setting_names']
                                   + succeeded_table['setting_names']
                                   + crashed_table['setting_names'])))

    # Handle the special case where no settings were tested.
    if not tested_names:
        page_html += html.add_indicator_box('info', 'No settings were tested') + '\n'
        return page_html

    summary = 'Settings tested'
    html_message = html.get_expandable_table(
        summary, tested_names, color_scheme=None
    )
    page_html += html.add_indicator_box('info', html_message) + '\n'

    number_tested = len(tested_names)
    setting_or_settings = add_s_if_plural('setting', number_tested)
    message = f'{len(tested_names)} {setting_or_settings} tested'
    page_html += html.add_indicator_box('info', message) + '\n'

    number_crashed = len(crashed_table['table_rows'])
    if number_crashed:
        test_or_tests = add_s_if_plural('test', number_crashed)
        page_html += html.add_indicator_box(
            'fail',
            f'{number_crashed} {test_or_tests} crashed',
            box_label='crash'
        ) + '\n'

    number_failed = len(failed_table['table_rows'])
    if number_failed:
        test_or_tests = add_s_if_plural('test', number_failed)
        page_html += html.add_indicator_box(
            'fail',
            f'{number_failed} {test_or_tests} failed'
        ) + '\n'

    if not number_failed + number_crashed:
        page_html += html.add_indicator_box('pass', 'All tests passed') + '\n'

    page_html += html.get_ending_html()

    return page_html


def format_failed(failed):
    """Get an expandable html table for the failed tests."""

    failed_tests = []
    failed_names = list(failed.keys())
    if failed_names:
        summary = 'Settings that failed'
        for setting_name in failed_names:
            errors = failed[setting_name]['errors']
            failed_tests.append(
                (setting_name,) + errors[0]
            )
            for error_tuple in errors[1:]:
                failed_tests.append(
                    ('',) + error_tuple
                )

        column_names = ['Setting name', 'Test name', 'Expected', 'Actual']
        html_message = html.get_expandable_table(
            summary,
            failed_tests,
            column_names=column_names,
            color_scheme='fail',
            cells_to_color=(0, 3)
        )
    else:
        html_message = ''

    return {'html': html_message,
            'table_rows': failed_tests,
            'setting_names': failed_names}


def format_succeeded(succeeded):
    """Get an expandable html table for the succeeded tests."""

    succeeded_names = list(succeeded.keys())
    if succeeded_names:
        summary = 'Settings that passed'
        html_message = html.get_expandable_table(
            summary, succeeded_names, color_scheme='pass'
        )
    else:
        html_message = ''

    return {'html': html_message,
            'table_rows': succeeded_names,
            'setting_names': succeeded_names}


def format_crashed(crashed):
    """Get an expandable html table for the crashed tests."""

    # 2020-10-06.  The functions format_succeeded and format_crashed are
    # similar.  They have not been combined into a single function because of
    # the possibility that additional formatting will be wanted for crashed
    # settings.

    crashed_names = list(crashed.keys())
    if crashed_names:
        summary = 'Settings that crashed'
        html_message = html.get_expandable_table(
            summary, crashed_names, color_scheme='fail'
        )
    else:
        html_message = ''

    return {'html': html_message,
            'table_rows': crashed_names,
            'setting_names': crashed_names}
