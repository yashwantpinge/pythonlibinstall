"""Main function for the BIOS auditor

Also contains helper functions to perform functions such as initialization.
"""
# Standard-library imports
import argparse
import json
from pathlib import Path

# Third-party imports
import hp_logging.logger as logger

# Local-library imports
from bios_auditor.preprocess import process_registry
from bios_auditor.scheduler import run_tests
from bios_auditor.storage import Reloadable

_LOG_FILE = 'bios_auditor.log'


def initialize_parser():
    """Define the argument parser for the main function."""
    parser = argparse.ArgumentParser()

    parser.add_argument(
        '--configuration',
        dest='configuration',
        action='store',
        required=False,
        default=None,
        help=('interface to use for interacting with BIOS, one of: '
              'wmi, ovmf')
    )

    # The default behavior of the auditor is to try to load the saved state.
    # This needs to be the default, since the opposite default could
    # accidentally lead to endlessly starting over again.
    parser.add_argument(
        '--initialize',
        dest='initialize',
        action='store_true',
        required=False,
        help=('turns off default behavior of trying to load a saved state, '
              'causing the auditor be initialized based on other input '
              'arguments')
    )

    parser.add_argument(
        '--input-file',
        dest='input_file',
        action='store',
        required=False,
        default=None,
        help=('filename for input file containing a list of settings to be, '
              'tested, required with initialize')
    )

    parser.add_argument(
        '--registry-file',
        dest='registry_file',
        action='store',
        required=False,
        default=None,
        help=('filename for the registry used to audit the BIOS, required '
              'with initialize')
    )

    parser.add_argument(
        '--start-new-log',
        dest='start_new_log',
        action='store_true',
        required=False,
        help=('turns off the default behavior of appending log messages '
              'to the file "auditor.log," instead overwriting the file '
              'if it already exists')
    )

    parser.add_argument(
        '--workspace',
        dest='workspace',
        action='store',
        required=False,
        default=None,
        help=('path to the workspace used by the BIOS auditor, all input '
              'and output files belong in the directory specified by '
              'this argument, default is the working directory')
    )

    parser.add_argument(
        '--log-file-path',
        dest='log_file_path',
        action='store',
        required=False,
        default=None,
        help=('path to the log file in which bios-auditor stores detailed '
              'messages, default is "auditor.log" in the workspace directory')
    )

    # The filename for the saved state of the bios auditor could be considered
    # a variable internal to the auditor, but an optional argument still
    # allows this filename to be set.
    parser.add_argument(
        '--bootstrap-file',
        dest='bootstrap_file',
        action='store',
        required=False,
        default='auditor_state.pickle',
        help=('filename of the saved state of the BIOS auditor, '
              'defaults to "auditor_state.pickle"')
    )

    return parser


def initialize(args):
    """Initialize the auditor state based on arguments passed to the main function."""
    # Load the input file of settings to be tested.
    args.input_file = args.workspace / args.input_file
    input_data = args.input_file.read_text().split()
    input_data = [line.strip() for line in input_data]

    # Load the registry.
    args.registry_file = args.workspace / args.registry_file
    with open(args.registry_file) as json_file:
        raw_registry = json.load(json_file)

    # Here we can insert a call to verify that all settings in the input data
    # are also in the registry.

    auditor_state = Reloadable(file_path=args.bootstrap_file, load=False)
    auditor_state.configuration = args.configuration
    auditor_state.registry = process_registry(raw_registry, input_data)
    auditor_state.not_started = input_data
    auditor_state.in_progress = {}
    auditor_state.succeeded = {}
    auditor_state.failed = {}
    # Dictionary of settings which caused an exception to be raised during
    # testing.
    auditor_state.crashed = {}
    auditor_state.reboot_counter = 0
    # Flag that tells whether the auditor itself (as opposed to a test) has
    # crashed due to an exception.
    auditor_state.status_ok = True

    return auditor_state


def main(main_args=None):
    """
    usage: python auditor.py [-h] [--configuration CONFIGURATION] [--initialize]
                         [--input-file INPUT_FILE]
                         [--registry-file REGISTRY_FILE] [--start-new-log]
                         [--workspace WORKSPACE]
                         [--log-file-path LOG_FILE_PATH]
                         [--bootstrap-file BOOTSTRAP_FILE]
    optional arguments:
      -h, --help            show this help message and exit
      --configuration CONFIGURATION
                            interface to use for interacting with BIOS, one of:
                            wmi, ovmf
      --initialize          turns off default behavior of trying to load a saved
                            state, causing the auditor be initialized based on
                            other input arguments
      --input-file INPUT_FILE
                            filename for input file containing a list of settings
                            to be, tested, required with initialize
      --registry-file REGISTRY_FILE
                            filename for the registry used to audit the BIOS,
                            required with initialize
      --start-new-log       turns off the default behavior of appending log
                            messages to the file "auditor.log," instead
                            overwriting the file if it already exists
      --workspace WORKSPACE
                            path to the workspace used by the BIOS auditor, all
                            input and output files belong in the directory
                            specified by this argument, default is the working
                            directory
      --log-file-path LOG_FILE_PATH
                            path to the log file in which bios-auditor stores
                            detailed messages, default is "auditor.log" in the
                            workspace directory
      --bootstrap-file BOOTSTRAP_FILE
                            filename of the saved state of the BIOS auditor,
                            defaults to "auditor_state.pickle"
    """
    parser = initialize_parser()
    args = parser.parse_args(main_args)

    if args.workspace:
        args.workspace = Path(args.workspace)
    else:
        args.workspace = Path.cwd()

    try:
        if not args.log_file_path:
            args.log_file_path = args.workspace / 'auditor.log'
        filemode = 'w' if args.start_new_log else 'a'
        logger.initialize_logging(args.log_file_path, filemode=filemode)

        if args.initialize:
            auditor_state = initialize(args)
        else:
            args.bootstrap_file = args.workspace / args.bootstrap_file
            auditor_state = Reloadable(file_path=args.bootstrap_file, load=True)

            if not auditor_state.status_ok:
                message = 'Bios auditor was called again after it crashed.'
                log_message = (
                    message +
                    '  Check for bugs in the bios_auditor.manager module.\n'
                )
                logger.print_alert_and_raise(
                    dev_log_message=log_message,
                    message_to_user=message + '\n'
                )

        auditor_state = run_tests(auditor_state)

    except logger.ReportedError:
        if 'auditor_state' not in locals():
            auditor_state = Reloadable(file_path='auditor_state.pickle',
                                       load=False)
        auditor_state.status_ok = False
    except Exception as ex:
        if 'auditor_state' not in locals():
            auditor_state = Reloadable(file_path='auditor_state.pickle',
                                       load=False)
        auditor_state.status_ok = False
        message_to_user = 'Bios auditor crashed.'
        try:
            if args.log_file_path:
                message_to_user += f'  See {args.log_file_path} for details.\n'
        except:  # pylint:  disable=bare-except
            pass
        dev_log_message = 'An exception was caught in auditor.main.\n'
        logger.print_alert(dev_log_message=dev_log_message,
                           message_to_user=message_to_user,
                           caught_exception=ex)

    logger.close_dev_log()
    auditor_state.save()
    return auditor_state
