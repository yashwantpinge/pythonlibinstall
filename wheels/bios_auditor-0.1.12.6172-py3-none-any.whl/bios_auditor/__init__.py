"""Define __version__ for bios_auditor package."""

try:
    from importlib.metadata import version
except ModuleNotFoundError:
    from importlib_metadata import version

try:
    __version__ = version(__name__)
except:  # pylint: disable=bare-except
    pass
