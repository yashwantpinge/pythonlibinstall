import importlib.resources as pkg_resources
import uuid
from enum import IntEnum, unique

import yaml
from hp_wmi.private_wmi import execute_private_wmi
from hp_wmi.private_wmi_defs import PrivateWmiCommands, SizeOut, PrivateWmiReturnCodes, PrivWmiRetCodeError
from hp_wmi.public_wmi import BiosSettings
from hp_wmi.public_wmi_defs import SettingNames

from hp_mpm import resources
from hp_mpm.cert_manager import sign_prism_packet
from .test_automation import inject_data


# Command types for Private WMI Command 20004h System Management Command (SMC)
@unique
class SmcCmdTypes(IntEnum):
    REQUEST = 5
    SET_MPM = 6


TEST_HOOK_PRISM_SMC_KEY_PRESS = uuid.UUID("3A3C5C71-CA87-4547-8CC3-5B41EDD27B21")
TEST_HOOK_UNLOCK_MPM = uuid.UUID("26EDED0C-62B7-43B9-80D9-7D1417BE8597")
TEST_HOOK_BYPASS_GLOBAL_PPI = uuid.UUID("7DBAC2F8-7123-4DBA-A5D5-46FFFF90443B")
default_branding_info = {
    SettingNames.PRODUCTNAME: "HP Test System",
    SettingNames.SERIALNUMBER: "123456789A",
    SettingNames.SKUNUMBER: "123SKU1#ABA",
    SettingNames.FEATUREBYTE: "dq.ar",
    SettingNames.BUILDID: "8079",
    SettingNames.HBMAFACTORYMAC: "12-34-56-78-90-AB",
    SettingNames.SYSTEMBOARDCT: "CAESARPCABOARD",
}


def save_branding_info(filepath="BrandingInfo.yaml"):
    """ Save current branding settings to a yaml file
     Args:
         filepath: file path to save to
     """
    if not filepath:
        raise TypeError("arg filepath must be a valid file name.")
    settings = BiosSettings()
    # Use default_branding_info as list of settings to retrieve, override values with current BIOS values
    for item in default_branding_info:
        default_branding_info[item] = settings[item]
    # Save to file
    with open(filepath, 'w') as save_file:
        documents = yaml.dump(default_branding_info, save_file)


def save_valid_branding_info(filepath="BrandingInfo.yaml"):
    """ Save only current branding settings with valid values to a yaml file
     Args:
         filepath: file path to save to
     """
    if not filepath:
        raise TypeError("arg filepath must be a valid file name.")
    settings = BiosSettings()
    # Use default_branding_info as list of settings to retrieve, override values with current BIOS values
    for item in default_branding_info:
        if settings[item] and not (item == SettingNames.HBMAFACTORYMAC and settings[item] == "00-00-00-00-00-00"):
            default_branding_info[item] = settings[item]
    # Save to file
    with open(filepath, 'w') as save_file:
        documents = yaml.dump(default_branding_info, save_file)


def set_branding_info(filepath=None) -> bool:
    """ Set Public WMI settings required to brand a system for MPM lock
    Args:
        filepath: if provided, settings from this YAML file are applied, regardless of current value.
        Otherwise, default values are applied only if current value is not set.
    Returns:
        True on success
    Raises:
        Exception KeyError on set value failure
    """
    # Get Public WMI class instance
    settings = BiosSettings()
    mpm_value = settings[SettingNames.MPM]
    if mpm_value != "Unlock":
        print("MPM must be unlocked to set branding info.")
        return False
    if filepath:
        # apply any settings in file
        with open(filepath) as file:
            branding_data = yaml.full_load(file)
        for item in branding_data:
            settings[item] = branding_data[item]
            # remove item from defaults dictionary
            if item in default_branding_info:
                del default_branding_info[item]
    # apply any remaining defaults
    for item in default_branding_info:
        if not settings[item] or (item == SettingNames.HBMAFACTORYMAC and settings[item] == "00-00-00-00-00-00"):
            settings[item] = default_branding_info[item]
    return True


def lock_mpm(filepath=None) -> bool:
    """ Lock Manufacturing Programming Mode (MPM) on a system
    Args:
        filepath: if provided, settings from this YAML file are applied in place of or in addition to defaults
    Returns:
        True if value changed
    Raises:
        Exception KeyError on failure
    """
    # Get Public WMI class instance
    settings = BiosSettings()
    mpm_setting = settings[SettingNames.MPM]
    if mpm_setting == "Lock":
        return False
    set_branding_info(filepath)
    settings[SettingNames.MPM] = "Lock"
    return True

def set_mpm_counter(pwd: str):
    settings = BiosSettings()
    mpm_value = settings[SettingNames.MPM]
    if mpm_value != "Lock":
        settings.set_value(SettingNames.MPMCOUNTER, "255", pwd)

def unlock_mpm(filepath="BrandingInfo.yaml"):
    """ Use PRISM server MPM command to unlock MPM only - with automated key press
    Factory Unlock All SMC is used along with a test hook to bypass SMC signature verification
    Caller must reboot before MPM unlock completes
    Args:
        filepath: where current branding settings are saved, if not None
    Raises:
        Exception on failure
    """
    if filepath:
        save_branding_info()
    # 1st trigger the fake keypress.
    _send_smc_key_press_test_hook()
    # Bypass SMC signature verification
    _send_mpm_unlock_only()
    # Non-existing certificate file provided to skip factory reset
    _execute_smc_set_mpm("BadTestKey")


def unlock_all(filepath="BrandingInfo.yaml"):
    """ Use PRISM server MPM command to unlock MPM and Intel ME - with automated key press.
    Factory Unlock All SMC is used
    Caller must reboot before MPM unlock completes
    Args:
        filepath: where current branding settings are saved, if not None
    Raises:
        Exception on failure
    """
    if filepath:
        save_branding_info()
    # 1st trigger the fake keypress.
    _send_smc_key_press_test_hook()
    # Valid certificate file provided to skip factory reset
    _execute_smc_set_mpm("PrismTestKey")


def disable_ppi():
    """ Disable setting "Physical Presence Interface", and send test hook to bypass the PPI it causes
    Returns:
        True if value changed
    Raises:
        Exception on failure
    """
    # Get Public WMI class instance
    settings = BiosSettings()
    ppi_value = settings[SettingNames.PHYSICALPRESENCE]
    if ppi_value != "Disable":
        ret_code = inject_data(TEST_HOOK_BYPASS_GLOBAL_PPI, bytearray([1]))
        if ret_code != PrivateWmiReturnCodes.SUCCESS:
            raise AssertionError("Send mpm unlock only test hook failed, return code: " + str(ret_code))
        settings[SettingNames.PHYSICALPRESENCE] = "Disable"
        return True
    return False


def _construct_prism_packet(key_name: str, smc_blob: bytearray) -> bytearray:
    """ Construct signed prism blob.
    Args:
        key_name:   Name of the certificate file to use to sign the data.
        smc_blob:   SMC data.
    Returns:
        Full SMC blob with signature.
    """
    if not type(key_name) == str:
        raise TypeError("Arg key_name must be of type str")
    if not type(smc_blob) == bytearray:
        raise TypeError("Arg smc_blob must be of type bytearray")

    # Create other necessary fields and then send the 'Prism' SMC
    nonce = _get_bios_nonce()
    smc_blob_byte_size = len(smc_blob).to_bytes(2, 'little')
    nonce_size_in_bytes = len(nonce).to_bytes(2, 'little')

    unsigned_blob = bytearray(smc_blob_byte_size + smc_blob + nonce_size_in_bytes + nonce)

    signature = sign_prism_packet(key_name, unsigned_blob)
    sig_size = len(signature).to_bytes(2, 'little')
    pkg_size = 4 + 3 * 2 + len(nonce) + len(smc_blob) + len(signature)
    pkg_byte_size = pkg_size.to_bytes(4, 'little')

    smc_input = pkg_byte_size + unsigned_blob + sig_size + bytearray(signature)
    return bytearray(smc_input)


def _get_bios_nonce() -> bytearray:
    """ Call private wmi to retrieve the BIOS nonce.
    Returns:
        The BIOS nonce.
    """
    ret_code, nonce_output = execute_private_wmi(PrivateWmiCommands.SMC, SmcCmdTypes.REQUEST, None, SizeOut.SIZE128)
    if ret_code != PrivateWmiReturnCodes.SUCCESS:
        raise PrivWmiRetCodeError(PrivateWmiCommands.SMC, SmcCmdTypes.REQUEST, PrivateWmiReturnCodes.SUCCESS, ret_code)
    # nonce_output should be 128 bytes, so copy to 16 byte array.
    return bytearray(nonce_output[0:16])


def _send_smc_key_press_test_hook():
    """ Emulate SMC {Win}+{M}+{P} key combination at startup with test hook """
    ret_code = inject_data(TEST_HOOK_PRISM_SMC_KEY_PRESS, bytearray([1]))
    if ret_code != PrivateWmiReturnCodes.SUCCESS:
        raise AssertionError("Send prism smc key press test hook failed, return code: " + str(ret_code))


def _send_mpm_unlock_only():
    """ Send test hook to bypass SMC signature verification to unlock MPM only, without factory reset
    Assumption is that a bad certificate will be sent to _execute_smc_set_mpm
    """
    ret_code = inject_data(TEST_HOOK_UNLOCK_MPM, bytearray([1]))
    if ret_code != PrivateWmiReturnCodes.SUCCESS:
        raise AssertionError("Send mpm unlock only test hook failed, return code: " + str(ret_code))


def _execute_smc_set_mpm(key_name: str):
    """ Execute SMC command to reset MPM. If key is valid full factory reset will be performed. """
    mpm_reset_blob = bytearray(pkg_resources.read_binary(resources, "MpmReset.smc"))
    smc_input = _construct_prism_packet(key_name, mpm_reset_blob)
    ret_code, _ = execute_private_wmi(PrivateWmiCommands.SMC, int(SmcCmdTypes.SET_MPM), smc_input, SizeOut.SIZE0)
    if ret_code != PrivateWmiReturnCodes.SUCCESS:
        raise AssertionError("Execute SMC reset MPM failed, return code: " + str(ret_code))
