""" Test automation support for MPM unlock
 This duplicates code in hp-uefi-test-hooks, but is needed here to avoid circular dependencies
"""
import uuid

from hp_wmi.private_wmi import *
from hp_wmi.private_wmi_defs import *


@unique
class TestAutomationType(IntEnum):
    COMMAND_SUPPORT = 0
    DATA_INJECTION = 2
    DATA_EXTRACTION = 3
    GETVARBACKDOOR = 0x10
    SETVARBACKDOOR = 0x11


def inject_data(guid: uuid.UUID, data_in: bytes or bytearray) -> int:
    """ Test automation data injection
    Args:
        guid: Test hook GUID ID
        data_in: Injected data
    Returns:
        Result code, 0 == success
    """
    if type(guid) != uuid.UUID:
        raise TypeError(type(guid))
    if type(data_in) != bytearray and type(data_in) != bytes:
        raise TypeError()

    data_size_in_bytes = bytearray(len(data_in).to_bytes(4, 'little'))
    in_buffer = bytearray(guid.bytes_le) + data_size_in_bytes + data_in
    ret_code, _ = execute_private_wmi(PrivateWmiCommands.TESTHOOKS, TestAutomationType.DATA_INJECTION, in_buffer,
                                      SizeOut.SIZE0)
    return ret_code
