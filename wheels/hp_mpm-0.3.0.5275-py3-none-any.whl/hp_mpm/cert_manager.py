""" Certificate support for MPM unlock """
import importlib.resources as pkg_resources
import os

from OpenSSL import crypto

from hp_mpm import resources

CERT_FILE_PASSWORD = bytes("pass123", "utf-8")
CERT_FILE_EXT = ".pfx"

def sign_for_ec(data, key):
    if type(data) != bytes:
        raise TypeError("arg data must be of type bytes.")
    if type(key) != crypto.PKey:
        raise TypeError("arg key must be of type crypto.PKey.")

    signed_data = crypto.sign(key,data,"RSA-sha256")

    return bytearray(reversed(signed_data))

def sign_prism_packet(key_name: str, data: bytearray) -> bytearray:
    """ Sign prism blob
    Args:
        key_name: Name of the certificate file to use to sign the data.
        data: The data to be signed.
    Returns:
        Signed prism blob.
    """
    if not type(key_name) == str:
        raise TypeError("Arg key_name must be of type str")
    if not type(data) == bytearray:
        raise TypeError("Arg data must be of type bytearray")

    prism_key = _get_pkcs12(key_name)
    # SMC currently still uses SHA1 in signatures.
    return bytearray(reversed(crypto.sign(prism_key.get_privatekey(), bytes(data), "RSA-sha1")))


def _generate_self_signed_X509_cert(key_pair):
    cert = crypto.X509()
    cert.get_subject().C = "US"
    cert.get_subject().ST = "Texas"
    cert.get_subject().L = "Houston"
    cert.get_subject().O = "Dis"
    cert.get_subject().CN = "www.example.com"
    cert.set_serial_number(1000)
    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(10 * 365 * 24 * 60 * 60)
    cert.set_issuer(cert.get_subject())
    cert.set_pubkey(key_pair)
    cert.sign(key_pair, 'sha256')
    return cert

def _get_pkcs12(cert_file_name):

    """ Get certificate blob """
    cert_file = cert_file_name + CERT_FILE_EXT

    # Is certificate file in resources?
    if pkg_resources.is_resource(resources, cert_file):
        cert_data = pkg_resources.read_binary(resources, cert_file)
    else:  # Read new certificate

        if not os.path.exists(cert_file_name):
            create_cert_file(cert_file_name)

        with open(cert_file, "rb") as cert_file:
            cert_data = cert_file.read()

    return crypto.load_pkcs12(cert_data, CERT_FILE_PASSWORD)

def get_pub_key_modulus_length(cert_obj):
    x509_obj = None
    if type(cert_obj) == crypto.PKCS12:
        x509_obj = cert_obj.get_certificate()
    else:
        x509_obj = cert_obj

    crypt_key = x509_obj.get_pubkey().to_cryptography_key()

    mod = crypt_key.public_numbers().n

    mod_size = (mod.bit_length() + 7) // 8

    return mod.to_bytes(mod_size, 'little')


def _create_cert_data() -> bytes:
    """ Create a new certificate blob """
    # create a key pair
    key = crypto.PKey()
    key.generate_key(crypto.TYPE_RSA, 2048)
    # create a self-signed cert
    cert = _generate_self_signed_X509_cert(key)
    pkcs12 = crypto.PKCS12()
    pkcs12.set_certificate(cert)
    pkcs12.set_privatekey(key)
    return pkcs12.export(CERT_FILE_PASSWORD)

def _generate_key_pair():
   # create a key pair
   k = crypto.PKey()
   k.generate_key(crypto.TYPE_RSA, 2048)

   return k

def _generate_pkcs12():
   # create a key pair
   k = _generate_key_pair()

   # create a self-signed cert
   cert = _generate_self_signed_X509_cert(k)

   pkcs12 = crypto.PKCS12()
   pkcs12.set_certificate(cert)
   pkcs12.set_privatekey(k)

   return pkcs12

def create_cert_file(certname):
    cert_file_name = certname + CERT_FILE_EXT

    if not os.path.exists(cert_file_name):
        pkcs12 = _generate_pkcs12()

        cert_file = open(cert_file_name, "wb")
        cert_file.write(pkcs12.export(CERT_FILE_PASSWORD))

        cert_file.close()

def get_cert_bytes(cert_obj):
    cert = None

    if type(cert_obj) == crypto.PKCS12:
        cert = cert_obj.get_certificate()
    else:
        cert = cert_obj

    return crypto.dump_certificate(crypto.FILETYPE_ASN1, cert)