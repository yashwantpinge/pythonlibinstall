# Changelog

## Version 0.3.0

### Add save_branding_info()
- Save current branding settings to a YAML file

### Add disable_ppi()
- Disable setting "Physical Presence Interface"

### Update set_branding_info()
- Add file parameter to provide branding values

### Update lock_mpm()
- Add file parameter to provide branding values

### Update unlock_mpm()
- Automatically save current branding settings

### Update unlock_all()
- Automatically save current branding settings

