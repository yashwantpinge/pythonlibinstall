# Definitions to help with HP Public WMI access
from enum import IntEnum, unique


# HP Public WMI main and sub-class names
class PublicWmiClass(str):
    SETTING = "HP_BIOSSetting"
    STRING = "HPBIOS_BIOSString"
    INT = "HPBIOS_BIOSInt"
    ENUMERATION = "HPBIOS_BIOSEnumeration"
    ORDEREDLIST = "HPBIOS_BIOSOrderedList"
    PASSWORD = "HPBIOS_BIOSPassword"
    USER = "HPBIOS_BIOSUser"


# Values returned by public WMI 'SetBIOSSetting' method, as defined in MOF.
@unique
class PublicWmiReturnCodes(IntEnum):
    SUCCESS = 0
    NOT_SUPPORTED = 1
    UNSPECIFIED_ERROR = 2
    TIMEOUT = 3
    FAILED = 4
    INVALID_PARAMETER = 5
    ACCESS_DENIED = 6
    BIOS_USER_ALREADY_EXISTS = 7
    BIOS_USER_NOT_PRESENT = 8
    BIOS_USERNAME_SIZE_EXCEEDS = 9
    BIOS_PWD_POLICY_NOT_MET = 10
    INVALID_KBD_LAYOUT = 11
    BIOS_USER_COUNT_EXCEEDED = 12
    SECURITY_POLICY_NOT_MET = 32768
    DEPENDENCY_CONDITION_ERROR = 32769
    CONFIGURATION_NOT_SUPPORTED = 32770


# Prefixes for the password types
class PublicWmiPasswordPrefix(str):
    NORMAL = "<utf-16/>"
    BEAM = "<BEAM/>"
    HPSR = "<hpsr/>"


# Standard setting names. For any system not all may be valid, and there may be others
class SettingNames(str):
    ABSOLUTEPERSISTENCEPERMANENTDISABLE = "Permanent Disable Absolute Persistence Module Set Once"
    ASSETTRACKINGNUMBER = "Asset Tracking Number"
    AUDIOALERTS = "Audio Alerts During Boot"
    BEAMACTIONSCOUNTER = "Enhanced BIOS Authentication Mode Actions Anti-Replay Counter"
    BEAMENABLEDISABLE = "Enhanced BIOS Authentication Mode"
    BEAMLOCALACCESSKEY = "Enhanced BIOS Authentication Mode Local Access Key 1"
    BEAMSETTINGSCOUNTER = "Enhanced BIOS Authentication Mode Settings Anti-Replay Counter"
    BIOSADMINPASSWORD = "Setup Password"
    BIOSBUILDVERSION = "Bios Build Version"
    BIOSVERSION = "System BIOS Version"
    BORNONDATE = "Born On Date"
    BUILDID = "Build ID"
    CONFIGURELEGACYSUPPORTSECUREBOOT = "Configure Legacy Support and Secure Boot"
    DEVICEGUARD = "Ready BIOS for Device Guard Use"
    DNS = "DNS Addresses"
    FASTBOOT = "Fast Boot"
    FEATUREBYTE = "Feature Byte"
    FINGERPRINTRESET = "Fingerprint Reset on Reboot"
    FIRMWARERUNTIMEINTRUSIONAMD = "HP Firmware Runtime Intrusion Detection"
    FIRMWARERUNTIMEINTRUSIONINTEL = "Enhanced HP Firmware Runtime Intrusion Prevention and Detection"
    HBMACUSTOMMAC = "HBMA Custom MAC Address"
    HBMAFACTORYMAC = "HBMA Factory MAC Address"
    HBMASYSTEMMAC = "HBMA System MAC Address"
    HPSURERUNPERMANENTDISABLE = "Permanently Disable HP Sure Run (Set Once)"
    INTELME = "Active Management (AMT)"
    INTELSGX = "Intel Software Guard Extensions (SGX)"
    INTEGRATEDMACADDRESS1 = "Integrated MAC Address 1"
    MEMORYSIZE = "Memory Size"
    MEFIRMWAREVERSION = "ME Firmware Version"
    MEFIRMWAREMODE = "ME Firmware Mode"
    MINBIOSVER = "Minimum BIOS Version"
    MPM = "Manufacturing Programming Mode"
    MPMLOCKREADINESS = "MPM Lock Readiness"
    MPMCOUNTER = "MPM Counter"
    NETWORKBOOT = "Network (PXE) Boot"
    OPTIONROMLAUNCHPOLICY = "Configure Option ROM Launch Policy"
    OSRECOVERY = "OS Recovery"
    OSRECOVERYAGENTVERSION = "OS Recovery Agent Version"
    OSRECOVERYDRIVERVERSION = "OS Recovery Driver Version"
    OSRECOVERYIMAGEVERSION = "OS Recovery Image Version"
    OWNERSHIPTAG = "Ownership Tag"
    PHYSICALPRESENCE = "Physical Presence Interface"
    POWERONPASSWORD = "Power-On Password"
    PRIMARYBATTERYSERIALNUMBER = "Primary Battery Serial Number"
    PROCESSOR1TYPE = "Processor 1 Type"
    PROCESSOR1SPEED = "Processor 1 Speed"
    PROCESSOR1STEPPING = "Processor 1 Stepping"
    PROCESSOR1CACHESIZE = "Processor 1 Cache Size"
    PROCESSOR1MICROCODEREVISION = "Processor 1 MicroCode Revision"
    PROCESSOR1CORES = "Processor 1 Cores"
    PROCESOR1SLOT1 = "Processor 1 Bottom-Slot 1(left)"
    PROCESSORSLOT2 = "Processor 1 Bottom-Slot 2(right)"
    PRODUCTNAME = "Product Name"
    PRODUCTFAMILY = "Product Family"
    REMOTEHARDWAREDIAGEXECUTIONSTATUS = "Remote HP PC Hardware Diagnostics Last Execution Status"
    RESTORECUSTOMDEFAULTS = "Apply Custom Defaults and Exit"
    RESTOREFACTORYDEFAULTS = "Apply Factory Defaults and Exit"
    RESTORESECURITYDEFAULTS = "Restore Security Settings to Factory Defaults"
    SAVECUSTOMDEFAULTS = "Save Custom Defaults"
    SAVERESTOREGPTHARDDRIVE = "Save/Restore GPT of System Hard Drive"
    SAVERESTOREMBRHARDDRIVE = "Save/Restore MBR of System Hard Drive"
    SECONDARYBATTERYSERIALNUMBER = "Secondary Battery Serial Number"
    SECUREBOOT = "Secure Boot"
    SECUREBOOTKEYSCLEAR = "Clear Secure Boot Keys"
    SECUREBOOTKEYSFACTORYRESET = "Reset Secure Boot Keys to factory defaults"
    SECUREBOOTKEYSIMPORT = "Import Custom Secure Boot Keys"
    SERIALNUMBER = "Serial Number"
    SKUNUMBER = "SKU Number"
    STORAGEDEVICES = "Storage Devices"
    SURESTARTBIOSSETTINGSPROTECTION = "Sure Start BIOS Settings Protection"
    SURESTARTSECURITYEVENTBOOTNOTIFICATION = "Sure Start Security Event Boot Notification"
    SURESTARTSECURITYEVENTPOLICY = "Sure Start Security Event Policy"
    SYSTEMBOARDCT = "System Board CT Number"
    SYSTEMBOARDID = "System Board ID"
    TPMCLEAR = "Clear TPM"
    TPMDEVICE = "TPM Device"
    TPMSTATE = "TPM State"
    UEFIBOOTORDER = "UEFI Boot Order"
    UUID = "Universally Unique Identifier (UUID)"
    USBCCONTROLLERVERSION = "USB Type-C Controller(s) Firmware Version:"
    VIDEOBIOSVERSION = "Video BIOS Version"
