import wmi
from .private_wmi_defs import SizeOut

def execute_private_wmi(command: int, command_type: int, in_data: bytearray or bytes or None, size_out: int) -> object:
    """BIOS Private WMI class method execution
    Args:
        command: Command identifier
        cmd_type: Command type
        input: Input data buffer or None
        size_out: Output data buffer size

    Returns:
        BIOS return code, data buffer bytearray

    Example:
        result, data = ExecutePrivateWmi(1, 0x0D,  None, 128)
        if result == 0:
            print(data)
    """
    if command < 0:
        raise ValueError("arg command must be greater than or equal to 0.")
    elif command_type < 0:
        raise ValueError("arg cmd_type must be greater than or equal to 0.")
    elif size_out < 0:
        raise ValueError("arg size_out must be greater than or equal to 0.")
    elif size_out > 4096:
        raise ValueError("arg size_out must be less than or equal to 4096.")
    if in_data is not None and type(in_data) != bytearray and type(in_data) != bytes:
        raise TypeError("arg input must be None or of type bytearray or bytes.")

    # open namespace
    c = wmi.WMI(namespace="WMI", find_classes=False)

    # set up input data instance
    in_instance = c.hpqBDataIn.new()
    in_instance.Sign = b'SECU'
    in_instance.Command = int(command)
    in_instance.CommandType = int(command_type)
    in_instance.Size = 0 if in_data is None else len(in_data)
    in_instance.hpqBData = in_data

    # get method class instance
    instance = c.hpqBIntM()[0]

    # execute method
    return_data = None
    if size_out == SizeOut.SIZE0:
        result, = instance.hpqBIOSInt0(InData=in_instance)
    elif size_out <= SizeOut.SIZE4:
        result, = instance.hpqBIOSInt4(InData=in_instance)
        return_data = result.Data
    elif size_out <= SizeOut.SIZE128:
        result, = instance.hpqBIOSInt128(InData=in_instance)
        return_data = result.Data
    elif size_out <= SizeOut.SIZE1024:
        result, = instance.hpqBIOSInt1024(InData=in_instance)
        return_data = result.Data
    elif size_out <= SizeOut.SIZE4096:
        result, = instance.hpqBIOSInt4096(InData=in_instance)
        return_data = result.Data
    else:
        raise ValueError("Invalid output data size")

    return result.rwReturnCode, return_data
