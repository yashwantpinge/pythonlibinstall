# Definitions to help with HP Private WMI access
# See "WMI BIOS Specification"
from enum import IntEnum, unique

# commonly used commands
@unique
class PrivateWmiCommands(IntEnum):
    READ                      = 0x1
    WRITE                     = 0x2
    SMC                       = 0x20004
    SURESTART3                = 0x20006
    HW_ENHANCED_PERSISTANCE   = 0x20010
    TESTHOOKS                 = 0x20012

# required output data sizes
@unique
class SizeOut(IntEnum):
    SIZE0    = 0
    SIZE4    = 4
    SIZE128  = 128
    SIZE1024 = 1024
    SIZE4096 = 4096

# private WMI return codes
@unique
class PrivateWmiReturnCodes(IntEnum):
    SUCCESS                   = 0
    DATA_PENDING              = 1
    INVALID_SIGNATURE         = 2
    INVALID_COMMAND           = 3
    INVALID_COMMAND_TYPE      = 4
    INVALID_DATA_SIZE         = 5
    INVALID_COMMAND_PARAMETER = 6
    GENERIC_FAILURE           = 0x1C
    P21_NOT_PROVISIONED       = 0x1000
    P21_ALREADY_PROVISIONED   = 0x1001
    P21_IN_USE                = 0x1002

class PrivWmiRetCodeError(Exception):
   """Exception raised for Private Wmi Commands that have unexpected return codes.

   Attributes:
      cmd_val:       the feature command as defined in the Private WMI spec
      cmd_type:      the command types as defined in the Private WMI spec
      expected:      the expected return code of the Private WMI command
      actual:        the actual return code of the Private WMI command
   """
   def __init__(self, cmd_val: int, cmd_type: int, expected: int, actual: int):
      self.cmd_val = cmd_val
      self.cmd_type = cmd_type
      self.expected = expected
      self.actual = actual
      self.message = f"Private WMI {self.cmd_val} type {self.cmd_type} return code is not " \
                     f"as expected. Expected: {self.expected}. Actual: {self.actual}."
