import wmi
from .public_wmi_defs import PublicWmiClass, PublicWmiReturnCodes, PublicWmiPasswordPrefix

class BiosSettings:

    def __init__(self):
        # Get Public WMI class instance
        self._instance = wmi.WMI(namespace=r"HP\InstrumentedBIOS", find_classes=False)


    def __getitem__(self, name) -> str:
        """ Get a Public WMI setting value using name as key
        Args:
            key: BIOS setting name

        Returns:
            string current value on success

        Raises:
            exception KeyError on failure

        Example:
            settings = hp_wmi.public_wmi.BiosSettings()
            value = settings[hp_wmi.SettingNames.BiosVersion]
            print(value)
        """
        return self.get_value(name)


    def __setitem__(self, name, value):
        """ Set a Public WMI setting value using name as key

        Args:
            name: BIOS setting name
            value: new value to set

        Raises:
            exception KeyError on failure

        Example:
            settings = hp_wmi.public_wmi.BiosSettings()
            settings[hp_wmi.SettingNames.OwnershipTag] = "New Ownership Tag"
        """
        result = self.set_value(name, value)
        if result != PublicWmiReturnCodes.SUCCESS:
            raise KeyError(f"Failed to set '{str(name)}' value, result = {result}.")


    def get_value(self, name) -> str:
        """ Get a Public WMI setting value

        Args:
            BIOS setting name

        Returns:
            string current value on success

        Raises:
            exception KeyError on failure

        Example:
            myvalue = get_value("System BIOS Version")
            print(myvalue)
        """
        settings = self._instance.HP_BIOSSetting(Name=str(name))
        if not settings:
            raise KeyError(f"Setting not found: '{str(name)}'")
        # Enum settings return all possible values, we just want the current one
        if settings[0].Path_.Class == PublicWmiClass.ENUMERATION:
            return settings[0].CurrentValue
        # Password settings never return a value, show if it is set or not
        elif settings[0].Path_.Class == PublicWmiClass.PASSWORD:
            return 'Set' if settings[0].IsSet else 'Not set'
        else:
            return settings[0].Value


    def set_value(self, name, value, password = "",
                  prefix: PublicWmiPasswordPrefix = PublicWmiPasswordPrefix.NORMAL) -> int:
        """ Set a Public WMI setting value

        Args:
            name: BIOS setting name
            value: new value to set
            password: BIOS password, if set
            prefix: password prefix, usually default

        Returns:
            result code, 0 on success

        Example:
            result = set_value("Ownership Tag", "My System", "Mypassword")
            print(result)
        """
        instance = self._instance.HP_BIOSSettingInterface()[0]
        pwd = str(prefix) + str(password)
        result, = instance.SetBIOSSetting(Name=str(name), Value=str(value), Password=str(prefix) + str(password))
        return result


    def set_value_beam(self, name, value, password) -> int:
        """ Set a Public WMI setting value with BEAM password

        Args:
            name: BIOS setting name
            value: new value to set
            password: BEAM password, if set

        Returns:
            result code, 0 on success
        """
        return self.set_value(name, value, PublicWmiPasswordPrefix.BEAM + password)


    def set_defaults(self, password = "",
                     prefix: PublicWmiPasswordPrefix = PublicWmiPasswordPrefix.NORMAL) -> int:
        """ Set Public WMI settings to system defaults

        Args:
            password: BIOS password, if set
            prefix:   password prefix, usually default

        Returns:
            result code, 0 on success
        """
        instance = self._instance.HP_BIOSSettingInterface()[0]
        result, = instance.SetSystemDefaults(Password=str(prefix) + str(password))
        return result


    def get_enum_all_values(self, name) -> str:
        """ Get all values of a Public WMI enum setting

        Args:
            name: BIOS setting name

        Returns:
            value list on success

        Raises:
            exception KeyError on failure
        """
        settings = self._instance.HP_BIOSEnumeration(Name=str(name))
        if not settings:
            raise KeyError(f"Setting not found: '{str(name)}'")
        return settings[0].PossibleValues


    def get_all_settings(self):
        """ Get the collection of all settings

        Returns:
            collection of all settings
        """
        return self._instance.HP_BIOSSetting()
