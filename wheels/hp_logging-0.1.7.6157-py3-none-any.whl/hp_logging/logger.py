"""Manage two loggers: a user logger for simple messages and a dev logger for
more detailed messages.

The logger module presents an API that mimics some API calls of the logging
module of the standard-library, such as error(), info(), etc.  However each of
these takes boolean arguments dev, user that determines whether the message is
sent to the (simple) user logger and/or the (more detailed) dev logger.

In addition to mimicking the logging API, the logger module has API functions
initialize_logging, configure, print_alert, print_alert_and_raise, and
decode_output.

  - initialize_logging, configure can be used to configure the user logger and
    the dev logger.

  - print_alert, print_alert_and_raise send error information to both loggers,
    optionally printing a traceback to the dev log and raising a
    logger.ReportedError exception

  - shutdown shuts down the logging system.

  - decode_output returns a python string based on stdout or stderr bytes
    captured during a call to subprocess.run.


Example usage:

import hp_logging.logger as logger

logger.initialize_logging('test.log')

logger.info('That one thing happened, here are details:  details.', dev=True)

logger.info('That one thing happened.', user=True)

message_to_user = 'That one bad thing happened.'
dev_log_message = message_to_user + '  Here are details:  details.'
logger.print_alert(dev_log_message, message_to_user)

try:
    [condition detected that prevents completion of the script]
    message_to_user = 'That one really bad thing happened.'
    dev_log_message = message_to_user + '  Here are details:  details.'
    logger.print_alert_and_raise(dev_log_message, message_to_user)
except logger.ReportedError:
    [ReportedError raised by print_alert_and_raise handled here]
    logger.shutdown()
    print('Exiting.\n', file = sys.stderr)
    return 1


Another example:

[Outer try-except in main checks for ReportedError raised anywhere by
logger.print_alert_and_raise.  The idea of ReportedError is that all useful
information has been logged, so if ReportedError is caught, a graceful exit
can be done.]
try:
    [move down into function calls, then "deep" in the stack do the following]
    try:
        [Do something simple that may cause various various exemptions to be
        raised]
    except Exception as ex:
        message_to_user = 'Could not do such-and-such'
        dev_log_message = message_to_user + ' and here are details:  details.'
        logger.print_alert_and_raise(dev_log_message, message_to_user,
                                     caught_exception=ex)
except logger.ReportedError:
    [ReportedError raised by print_alert_and_raise handled here]
    logger.shutdown()
    print('Exiting.\n', file = sys.stderr)
    return 1
"""
# Standard library imports
from datetime import datetime
import logging
import logging.config
import sys
import traceback

# Import DEBUG, INFO, etc from the logging module so that they can be accessed
# from the current module.  The goal is for the current module to be a
# self-contained interface for logging.
from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL

# Simple generic messages are sent to the user log.
_USER_LOGGER = logging.getLogger(__name__ + '_user')

# The dev log receives more detailed messages, to be read by developers.
_DEV_LOGGER = logging.getLogger(__name__ + '_dev')


# Exception raised by print_alert_and_raise.
class ReportedError(Exception):
    """Exception raised after all available information regarding an error
    condition has been logged and presented to the user.

    A block that handles only this class of exception can call sys.exit(1) to
    exit gracefully without loss of information about the error condition.
    """


# API that mimics the logging module of the standard library.
def _write(level, message, user, dev):
    """Send log message to requested logger(s) at requested level."""
    if not dev and not user:
        raise ValueError(
            'One of the arguments user, dev to logger._write must be True'
        )

    message = guarantee_newline_ending(message)

    if user:
        _USER_LOGGER.log(level=level, msg=message)

    if dev:
        _DEV_LOGGER.log(level=level, msg=message)


def critical(message, user=False, dev=True):
    """Write a message to the user and/or dev log at the CRITICAL level."""
    _write(level=CRITICAL, message=message, user=user, dev=dev)


def error(message, user=False, dev=True):
    """Write a message to the user and/or dev log at the ERROR level."""
    _write(level=ERROR, message=message, user=user, dev=dev)


def warning(message, user=False, dev=True):
    """Write a message to the user and/or dev log at the WARNING level."""
    _write(level=WARNING, message=message, user=user, dev=dev)


def info(message, user=False, dev=True):
    """Write a message to the user and/or dev log at the INFO level."""
    _write(level=INFO, message=message, user=user, dev=dev)


def debug(message, user=False, dev=True):
    """Write a message to the user and/or dev log at the DEBUG level."""
    _write(level=DEBUG, message=message, user=user, dev=dev)


def shutdown():
    """Perform and orderly shutdown of the logging system."""
    logging.shutdown()


def close_dev_log():
    """Close the FileHandler for the dev log."""
    _DEV_LOGGER.handlers[0].close()


def initialize_logging(dev_log_file_path, user_log_file=sys.stderr,
                       level=INFO, filemode='w',
                       name=None, run_number=None):
    """Configures logging and prints information about log file location.

    Example of how this function can be used:

    import hp_logging.logger as logger

    print('Merging firmware.\n')
    logger.initialize_logging(log_file_path)
    logger.info('Executing main function of merge module.\n')

    The first print statement in the example above, done before logging is
    configured, gives information to a user who may not read the log.  The
    function initialize_logging prints the location of the log file to stdout,
    and once that has been done, detailed logging information can be added to
    the log using logger.info().

    A header with datetime is generated in the dev log by current function, in
    order to mark the point at which a particular period of logging began.

    Args:
        dev_log_file_path:  string or pathlib.Path giving path to dev log
            file.

        user_log_file:  (optional) file passed to the StreamHandler for the
            user log.  Defaults to sys.stderr, but can be sys.stdout or an open
            file.

        level:  (optional) The level of events tracked in the log.  Should be
            one of DEBUG, INFO, WARNING, ERROR, CRITICAL, which are
            module-level constants.  If the value passed for level is not
            recognized, the default value INFO is used.

        filemode:  (optional) the mode in which to open the log file for the
            dev logger.  Defaults to 'w', but can be set to 'a' for append.

        name:  (optional) A name used to identify the logger in the header.

        run_number:  (optional) A run number to be added to the header.
    """

    # pylint: disable=too-many-arguments

    if len(_USER_LOGGER.handlers) > 0 or len(_DEV_LOGGER.handlers) > 0:
        error_message = (
            'Unable to perform basic configuration for hp_logging, since '
            'one or both of the loggers already has a handler.'
        )
        print(error_message, file=sys.stderr, flush=True)
        return

    if level not in {DEBUG, INFO, WARNING,
                     ERROR, CRITICAL}:
        level = INFO

    _USER_LOGGER.setLevel(level)
    _DEV_LOGGER.setLevel(level)

    try:
        dev_log_handler = logging.FileHandler(
            filename=dev_log_file_path, mode=filemode
        )
        dev_log_handler.setLevel(level)
        dev_log_formatter = logging.Formatter('%(levelname)s: %(message)s')
        dev_log_handler.setFormatter(dev_log_formatter)
        _DEV_LOGGER.addHandler(dev_log_handler)
        # The detailed messages that go to _DEV_LOGGER should not propagate to
        # other logs (e.g., a robot-framework log).
        _DEV_LOGGER.propagate = False

        user_log_handler = logging.StreamHandler(stream=user_log_file)
        user_log_handler.setLevel(level)
        user_log_formatter = logging.Formatter('%(levelname)s: %(message)s')
        user_log_handler.setFormatter(user_log_formatter)
        _USER_LOGGER.addHandler(user_log_handler)
        # The simple messages that go to _USER_LOGGER by default will
        # propagate.
        _USER_LOGGER.propagate = True
    except Exception as ex:
        log_message = 'Configuration of logging failed.\n'
        print_alert(log_message, caught_exception=ex, file=sys.stderr)

    # Print the file_path for _DEV_LOGGER to stdout.
    try:
        dev_log_file_path = _DEV_LOGGER.handlers[0].baseFilename
    except Exception as ex:
        log_message = (
            'Could not get the path to the log file.\n'
            'Logging may not be configured correctly.\n'
        )
        print_alert(log_message, caught_exception=ex, file=sys.stderr)
    else:
        print(f'A log is being written to\n"{dev_log_file_path}"\n')

    # Print a header to the dev log.
    if not name:
        name = 'Logger'
    else:
        name = name + ' logger'
    message = '\n' + '#' * 60 + f'\n\n{name} initialized'
    if run_number:
        message += f', run {run_number}'
    timestamp = '\n\n' + datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    message += timestamp + '\n\n' + '#' * 60 + '\n'
    info(message)


def configure(user_log_config=None, dev_log_config=None):
    """Configure the user and/or dev logger.

    The  arguments user_log_config and dev_log_config are dictionaries that
    match the configuration dictionary schema of the standard-library logging
    module.  As explained in the docs for the module, configuration
    dictionaries can be read from a json or yaml file.
    """
    config = {'loggers': {_USER_LOGGER.name: user_log_config,
                          _DEV_LOGGER.name: dev_log_config}}
    logging.config.dictConfig(config)


def decode_output(output):
    """Return a Python string corresponding to stdout or stderr captured by
    subprocess.run

    Args:
        output:  Should be result.stdout or result.stderr, where result is
            the object returned by subprocess.run (with stdout=subprocess.PIPE
            and/or stderr=subprocess.PIPE in the call to subprocess.run).

    Returns:
        Python string corresponding to the captured output.
    """
    # The output from the program is a bytes object, so we decode it in
    # order to get a string.  Also, the output explicitly includes '\r\n'
    # for new lines.  Python converts '\n' to '\r\n' when writing to file,
    # so '\r\n' gets converted to '\r\r\n'.  In order to avoid doubling the
    # carriage returns, we eliminate them from the program output.
    return output.decode().replace('\r', '')


def _generate_traceback(caught_exception=None):
    """Generate a full stack trace

    Functions in the traceback module that produce a formatted traceback in a
    single command give a stack trace from the point of the caller down the
    stack to the point where the exception was generated.  In order to get a
    full stack trace, a couple of calls to functions in the traceback module
    are needed.  These are combined in the function _generate_traceback.
    """
    # Construct a StackSummary object.
    raw_traceback = traceback.extract_stack()

    # Discard the final two frames.  The final frame is the one for the current
    # function, and the second-to-last frame is for a function such as
    # print_alert or print_alert_and_raise called from the point where the
    # error occurred.
    raw_traceback = raw_traceback[:-2]

    # If this traceback is being generated because of a caught exception, then
    # the traceback should be modified to show that.
    if caught_exception:
        exception_traceback = traceback.extract_tb(
            caught_exception.__traceback__
        )
        raw_traceback[-1] = exception_traceback[-1]

    traceback_str = (
            'Traceback (most recent call last):\n'
            + ''.join(traceback.format_list(raw_traceback))
    )

    return traceback_str


def guarantee_newline_ending(message):
    """Check whether a message ends in \n and appends \n if not

    The log produced by the logging module is hard to read unless each message
    printed to the log has a \n at the end the message, so that consecutive
    log messages are separated by a blank line.
    """
    if not message.endswith('\n'):
        message += '\n'
    return message


def print_alert_and_raise(dev_log_message,
                          message_to_user=None,
                          caught_exception=None,
                          level=ERROR,
                          exception_to_raise=ReportedError,
                          stop_logging=False,
                          file=None):
    """Print/log error messages to multiple locations and then raise a new
    exception.

    In typical use, the function prints a detailed error message to the dev
    log and a simpler error message to the user log before raising
    ReportedError, an exception defined in the current module to indicate that
    all useful information has been logged, so a graceful exit can be done.
    An outer try-except calls shutdown and then exits when ReportedError is
    caught.

    Note that logging should be configured before the function is called,
    e.g., by calling initialize_logging.

    If an exception is passed to the function as argument caught_exception,
    information about the exception (including the traceback) is printed to the
    dev log.  If caught_exception is not passed, the full traceback (excluding
    the frame of the current function) is printed to the log instead.

    After printing error messages, the function raises an exception whose
    class is given by the argument exception_to_raise.  This defaults to
    ReportedError.

    See examples of usage in the module docstring or the README.md file for the
    package.

    Args:
        dev_log_message:  (optional) A detailed error messaged sent to the dev
            log.

        message_to_user:  (optional) A simple error message sent to the user
            log.  If message_to_user is None (the default value), then
            dev_log_message is printed as the message to the user.  This
            default allows the function to be used without the burden of
            writing two error messages.

        caught_exception:  (optional)  An exception that has previously been
            caught in an exception handler.  The details of caught_exception
            will be printed to the log.

        level:  (optional) The logging level to use in printing to the log.
            Should be one of DEBUG, INFO, WARNING, ERROR, CRITICAL.  If the
            value passed for level is not recognized, the default value ERROR
            is used.

        exception_to_raise:  (optional) The exception class to be raised after
            error messages are printed (default value ReportedError).  If
            SystemExit is passed for this argument, the result is equivalent
            to calling sys.exit(1) after error messages are printed.

        stop_logging:  (optional)  Boolean that determines whether to shut down
            logging before raising the exception.  The default is False, but
            stop_logging should be set to True in order to cleanly flush the
            logging system if the exception that is raised will not be handled
            by an outer catch.

        file:  (optional) Addition destination to which message_to_user is
            printed with the print command.  This argument can be used to
            ensure that an error message is printed if logging has not been
            configured.  Defaults to None, which bypasses direct printing of
            message_to_user.
    """

    # pylint: disable=too-many-arguments

    dev_log_message = guarantee_newline_ending(dev_log_message)

    if not message_to_user:
        message_to_user = dev_log_message

    # We want to create a full traceback to the point where the current
    # function was called.  A custom function _generate_traceback in the
    # current module does this.  The traceback excludes the frame of the
    # function _generate_traceback as well as the frame of the function calling
    # _generate_traceback, e.g., the current function.  Since exactly two
    # frames will be excluded, we should generate the traceback here (with
    # information about any caught exception), rather than passing that task
    # on to the function print_alert, which is called below.
    traceback_str = _generate_traceback(caught_exception)
    dev_log_message = dev_log_message + '\n' + traceback_str
    if caught_exception:
        exception_message_list = traceback.format_exception_only(
            type(caught_exception), caught_exception
        )
        exception_message = ''.join(exception_message_list)
        dev_log_message = dev_log_message + exception_message

    print_alert(dev_log_message=dev_log_message,
                message_to_user=message_to_user,
                level=level,
                file=file)

    if stop_logging:
        # Perform an orderly shutdown of logging.
        logging.shutdown()

    raise exception_to_raise('Error details have been logged.\n')


def print_alert(dev_log_message,
                message_to_user=None,
                caught_exception=None,
                level=ERROR,
                file=None):
    """Print/log error messages to multiple locations.

    In typical use, the function prints a detailed error/warning message to the
    dev log and a simpler error/warning message to the user log without
    terminating the script.

    The main difference between the functions print_alert,
    print_alert_and_raise is that print_alert does not raise an exception.
    Please see the docstring for print_alert_and_raise for details regarding
    the printing of error messages.

    Differences in the arguments for the two functions:

      - print_alert does not accept arguments stop_logging or
        exception_to_raise.

      - If caught_exception is None, print_alert_and_raise prints a full
        traceback to the dev log, but print_alert does not print any tracback.
        (If an exception caught by an exception handler is passed for this
        argument, however, it is handled in the same way by the two functions.)
    """
    dev_log_message = guarantee_newline_ending(dev_log_message)

    if not message_to_user:
        message_to_user = dev_log_message

    if caught_exception:
        traceback_str = _generate_traceback(caught_exception)
        exception_message_list = traceback.format_exception_only(
            type(caught_exception), caught_exception
        )
        exception_message = ''.join(exception_message_list)
        dev_log_message = (dev_log_message + '\n'
                           + traceback_str
                           + exception_message)
        dev_log_message = guarantee_newline_ending(dev_log_message)

    if level not in {DEBUG, INFO, WARNING, ERROR, CRITICAL}:
        level = ERROR

    _write(level=level, message=dev_log_message, user=False, dev=True)
    _write(level=level, message=message_to_user, user=True, dev=False)

    # If an argument such as sys.stderr has been passed for the file argument,
    # print message_to_user using the print command.
    if file:
        level_indicators = {DEBUG: 'DEBUG', INFO: 'INFO', WARNING: 'WARNING',
                            ERROR: 'ERROR', CRITICAL: 'CRITICAL'}

        message_to_user = level_indicators[level] + ': ' + message_to_user

        print(message_to_user, file=file, flush=True)
