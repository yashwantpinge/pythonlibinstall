import logging
import wmi

CreateFlag1 = "echo Run buff2 and flash BIOS > fs%myfs%:\\flag1.txt\n"
CreateFlag1Amd = "echo Run AmdFlash.efi and flash BIOS > fs%myfs%:\\flag1.txt\n"
Path = "fs%myfs%:\\"

ScriptStart = ("for %a run (0 100)\n" +
               "\tset -v myfs %a\n" +
               "\tif exist FS%myfs%:\\buff2.efi then\n" +
               "\t\tfs%myfs%:\n" +
               "\t\tgoto FSFOUND\n" +
               "\tendif\n" +
               "endfor\n" +
               "goto DONE\n" +
               ":FSFOUND\n" +
               "cls\n")

ScriptStartAmd = ("for %a run (0 100)\n" +
                  "\tset -v myfs %a\n" +
                  "\tif exist FS%myfs%:\\AmdFlash.efi then\n" +
                  "\t\tfs%myfs%:\n" +
                  "\t\tgoto FSFOUND\n" +
                  "\tendif\n" +
                  "endfor\n" +
                  "goto DONE\n" +
                  ":FSFOUND\n" +
                  "cls\n")

ScriptStartSmbios = ("for %a run (0 100)\n" +
                     "set -v myfs %a\n" +
                     "if exist FS%myfs%:\\EFI\\Microsoft\\Boot\\bootmgfw.efi then\n" +
                     "fs%myfs%:\n" +
                     "goto FSFOUND\n" +
                     "endif\n" +
                     "endfor\n" +
                     "goto DONE\n" +
                     ":FSFOUND\n" +
                     "cls\n")

EeUpdateToSaveMac = ("echo Run EeUpdate64e to save MAC address to file.\n" +
                     "fs%myfs%:\\eeupdate64e.efi /MAC_DUMP_FILE /NIC= 1\n")

EeUpdateToFlashMac = ("echo Run EeUpdate64e to reflash MAC address from saved file.\n" +
                      "fs%myfs%:\\eeupdate64e.efi /NIC=1 /A mac.txt > fs%myfs%:\\flag_step2.txt\n")

Reset = "fs%myfs%:\\buff2.efi  /reset\n"

ResetAmd = "reset\n"

CreateFlag3 = "\techo Now reset system using buff2. > fs%myfs%:\\flag3.txt\n"

Endifstatement = "endif\n"

DeleteFlagFactoryFlash = ("echo Delete flag.\n" +
                          "del fs%myfs%:\\flag_step2.txt\n")

SetFileNameFlag2 = "set filename2 Flag2\n"
DelMacTxt = "del fs%myfs%:\\mac.txt\n"
DelEeLog = "del fs%myfs%:\\eelog.dat\n"

IfFlag1Exist = "if exist fs%myfs%:\\flag1.txt then\n"
DelFlag1 = "del fs%myfs%:\\flag1.txt\n"

DelDebugLog = "del fs%myfs%:\\Debug.log\n"
StartWindowsOs = "\tFS%myfs%:\\EFI\\Microsoft\\Boot\\bootmgfw.efi\n"

IfFlag2Exist = "if exist fs%myfs%:\\flag2.txt then\n"
DelFlag2 = "\tdel fs%myfs%:\\flag2.txt\n"
CreateFlag2 = "echo Factory flashing complete > fs%myfs%:\\flag2.txt\n"
CreateFlag2Amd = "echo AmdFlash.efi flashing complete > fs%myfs%:\\flag2.txt\n"
CreateFlag2Fail = "\techo Factory flashing failed > fs%myfs%:\\flag2.txt\n"
CreateFlag2AmdFail = "\techo AmdFlash flashing failed > fs%myfs%:\\flag2.txt\n"

IfMeClosedFlagExist = "if exist fs%myfs%:\\MeClosedFlag.txt then\n"
DelMeClosedFlag = "\tdel fs%myfs%:\\MeClosedFlag.txt\n"
CreateMeClosedFlag = "\techo Closing ME Manufacturing mode is complete > fs%myfs%:\\MeClosedFlag.txt\n"

SmbiosView = "\tsmbiosview > \"smbiosview.txt\"\n"

Bcfgdump = "\tbcfg boot dump > \"bcfg.txt\"\n"

CreateReportTxtFail = "\techo EFI_STATUS:        Fail > fs%myfs%:\\report.txt\n"

ClearReportTxt = "del fs%myfs%:\\report.txt\n"

FptScriptStart = "for %a run (0 100)\n" + \
                 "set -v myfs %a\n" + \
                 "if exist FS%myfs%:\\fpt.efi then\n" + \
                 "fs%myfs%:\n" + \
                 "goto FSFOUND\n" + \
                 "endif\n" + \
                 "endfor\n" + \
                 "goto DONE\n" + \
                 ":FSFOUND\n" + \
                 "cls\n"

FptEfiStringClsMnf = "fpt.efi -closemnf NO -y > fpt1.log\n"

FptEfiStringHpFlmstr = "fpt.efi -f HP_FLMSTR5.bin -a 0x90 -l 4 > fpt2.log\n"

FptEfiStringGreset = "fpt.efi -greset\nreset\n"

IfStartMeClosingFlagExist = "if exist FS%myfs%:\\MeClosingFlag.txt then\n"
DelStartMeClosingFlag = "\tdel fs%myfs%:\\MeClosingFlag.txt\n"
GoToStartMeClosing = "\tgoto StartMeClosing\n"
StartMeClosingLabel = ":StartMeClosing\n"
CreateMeClosingFlag = "\techo Start Me Closing Sequence > fs%myfs%:\\MeClosingFlag.txt\n"
Done = ":DONE"


def create_fptefi_script() -> str:
    """
    Generates UEFI Shell Script to close Intel ME manufacturing mode with the FPT-efi tool
    """
    return (FptScriptStart +  # select file system
            IfStartMeClosingFlagExist +  # seek for MeClosingFlag.txt and branch if exists
            DelStartMeClosingFlag +  # delete MeClosingFlag.txt
            GoToStartMeClosing +  # jump to the ME closing sequence
            Endifstatement +  # end if statement
            IfMeClosedFlagExist +  # seek for MeClosedFlag.txt and branch if exists
            DelMeClosedFlag +  # delete MeClosedFlag.txt
            StartWindowsOs +  # boot to OS
            Endifstatement +  # end if statement
            CreateMeClosingFlag +
            FptEfiStringGreset +  # FPT global reset before starting closing sequence so me client is available
            StartMeClosingLabel +
            FptEfiStringClsMnf +  # FPT command with close manufacturing mode option
            FptEfiStringHpFlmstr +  # FPT command with inserting the binary to the offset option
            CreateMeClosedFlag +  # create MeClosedFlag.txt file
            FptEfiStringGreset +  # FPT global reset or reset if FPT greset fails
            Done)


def create_amdflash_script(bin_file: str) -> str:
    """ Generates UEFI Shell Script to perform factory flash using AMDFlash.efi
        Args:
            bin_file: BIOS image filename
        Returns:
            UEFI Shell Script
        """
    flash_type = '-F'

    amdflash_cmd_line = f"fs%myfs%:\\AmdFlash.efi {flash_type} {bin_file} > fs%myfs%:\\report.txt\n"

    script = (SetFileNameFlag2 +
              ScriptStartAmd +
              IfFlag1Exist +
              DelFlag1 +
              CreateFlag2AmdFail +
              CreateReportTxtFail +
              Endifstatement +
              IfFlag2Exist +
              DelFlag2 +
              StartWindowsOs +
              Endifstatement +
              ClearReportTxt +
              CreateFlag1Amd +
              amdflash_cmd_line +
              DelFlag1 +
              DeleteFlagFactoryFlash +
              DelDebugLog +
              CreateFlag2Amd +
              ResetAmd +
              Done)
    logging.debug(f"Script generated:\n{script}")
    return script


def create_flash_script(bin_file: str, flash_type: str) -> str:
    """ Generates UEFI Shell Script to perform factory flash using BUFF2
    Args:
        bin_file: BIOS image filename
        flash_type: Flash type to perform: 'all', 'bios only', or 'me
    Returns:
        UEFI Shell Script
    """
    if _is_intel():
        return create_intel_flash_script(bin_file, flash_type)
    else:  # AMD
        return create_amd_buff2_script(bin_file, flash_type)


def create_intel_flash_script(bin_file: str, flash_type: str) -> str:
    """ Generates UEFI Shell Script to perform factory flash using BUFF2
    Args:
        bin_file: BIOS image filename
        flash_type: Flash type to perform: 'all', 'bios only', or 'me
    Returns:
        UEFI Shell Script
    """
    if not flash_type.lower() in ['all', 'bios', 'me']:
        raise TypeError(f"Invalid flash type: {flash_type}")

    buff2_cmd_line = f"fs%myfs%:\\buff2.efi {bin_file} /{flash_type} > fs%myfs%:\\report.txt\n"

    script = (SetFileNameFlag2 +
              ScriptStart +
              IfFlag1Exist +
              DelFlag1 +
              CreateFlag2Fail +
              CreateReportTxtFail +
              Endifstatement +
              IfFlag2Exist +
              DelFlag2 +
              StartWindowsOs +
              Endifstatement +
              EeUpdateToSaveMac +
              ClearReportTxt +
              CreateFlag1 +
              buff2_cmd_line +
              DelFlag1 +
              EeUpdateToFlashMac +
              DelMacTxt +
              DelEeLog +
              DeleteFlagFactoryFlash +
              DelDebugLog +
              CreateFlag2 +
              Reset +
              Done)
    logging.debug(f"Script generated:\n{script}")
    return script


def create_amd_buff2_script(bin_file: str, flash_type: str) -> str:
    """ Generates UEFI Shell Script to perform factory flash using BUFF2
    Args:
        bin_file: BIOS image filename
        flash_type: Flash type to perform: 'all', 'bios only', or 'me
    Returns:
        UEFI Shell Script
    """
    if not flash_type.lower() in ['all', 'bios', 'me']:
        raise TypeError(f"Invalid flash type: {flash_type}")

    buff2_cmd_line = f"fs%myfs%:\\buff2.efi {bin_file} /{flash_type} > fs%myfs%:\\report.txt\n"

    script = (SetFileNameFlag2 +
              ScriptStart +
              IfFlag1Exist +
              DelFlag1 +
              CreateFlag2Fail +
              CreateReportTxtFail +
              Endifstatement +
              IfFlag2Exist +
              DelFlag2 +
              StartWindowsOs +
              Endifstatement +
              ClearReportTxt +
              CreateFlag1 +
              buff2_cmd_line +
              DelFlag1 +
              DeleteFlagFactoryFlash +
              DelDebugLog +
              CreateFlag2 +
              Reset +
              Done)
    logging.debug(f"Script generated:\n{script}")
    return script


def create_smbios_data_script() -> str:
    """ Generates UEFI Shell Script to get SMBIOS data
    Returns:
        UEFI Shell Script
    """
    return (ScriptStartSmbios +
            Bcfgdump +
            SmbiosView +
            StartWindowsOs +
            Done)


def create_boot_os_script() -> str:
    return (ScriptStart +
            StartWindowsOs +
            Done)


def _is_intel():
    """ Extract the CPU brand from the Win32_Processor name
     Returns:
         True if Intel
    """
    c = wmi.WMI()
    for instance in c.Win32_Processor():
        return "Intel" in instance.Name
