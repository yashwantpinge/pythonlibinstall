import logging
import numpy
from firmware_variables import *


class BiosBootOrder(object):

    def __init__(self):
        self._vcosmosBootEntryId = 0x6969
        self._originalBootEntryId = 0x0004
        self._bootOrderVar = "BootOrder"

    def change_boot_order(self):
        """ Change system boot order to load EFI shell """
        with privileges():
            order = get_boot_order()
            if len(order) == 0:
                raise KeyError(f"Get Boot Order for VarName {self._bootOrderVar} failed.")
            newBootOrder = numpy.empty(len(order) + 1, dtype=list)
            for i in range(0, len(order)):
                newBootOrder[i + 1] = order[i]
            newBootOrder[0] = self._vcosmosBootEntryId
            load_option = get_parsed_boot_entry(order[0])
            load_option.description = "vCosmos Efi Boot Entry"
            load_option.file_path_list.set_file_path("bootx64.efi")
            set_parsed_boot_entry(newBootOrder[0], load_option)
            set_boot_order(newBootOrder)
            logging.info(f"Set Boot Order for VarName {self._bootOrderVar} - Exit Success")

    def restore_boot_order(self):
        """ Restore system boot order to load Windows """
        with privileges():
            order = get_boot_order()
            load_option = get_parsed_boot_entry(order[0])
            if order[0] == self._vcosmosBootEntryId:
                logging.info(f"Restoring Boot Order for VarName {self._bootOrderVar}")
                restoreBootOrder = numpy.empty(len(order) - 1, dtype=list)
                for i in range(1, len(order)):
                    restoreBootOrder[i - 1] = order[i]
                set_boot_order(restoreBootOrder)
                logging.info(f"Boot Order restored for VarName {self._bootOrderVar} - Exit Success")
            elif "Windows" in load_option.description:
                logging.debug(f"Boot Order already restored for VarName {self._bootOrderVar}")
            else:
                logging.error(f"Failed to remove vCosmos Boot Entry {self._vcosmosBootEntryId}.")
