"""
Setup and execute a factory flash. This takes several steps:
Copy files needed to EFI partition on the target, including BIOS image, shell and shell startup script. Corrupt image if
  required by test.
Prepare for flashing by disabling some features like secure boot, fast boot.
Boot to shell to start the flash, which involves changing the boot order via Windows and restoring it after the flash.
"""
import os
import shutil
import uuid

import hp_mpm
from hp_wmi.public_wmi import *
from hp_wmi.public_wmi_defs import *
from hp_wmi.private_wmi_defs import *

from . import test_hooks

# Source location of files needed for flashing
_flashing_files_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "FlashingFiles")
# List of files needed for flashing
_flashing_files = ["bootx64.efi", "BUFF2.efi", "eeupdate64e.efi"]
_amdflash_file = ["bootx64.efi", "AmdFlash.efi"]
TEST_HOOK_ME_MODE = uuid.UUID("E464EAF5-62CB-4AC2-A3f5-E4A47F3AAF51")

def copy_amdflash_files(efi_partition_path: str):
    """ Copy Amd flashing files to EFI partition """
    for filename in _amdflash_file:
        shutil.copy2(os.path.join(_flashing_files_dir, filename), efi_partition_path)


def copy_buff_files(efi_partition_path: str):
    """ Copy flashing files to EFI partition """
    for filename in _flashing_files:
        shutil.copy2(os.path.join(_flashing_files_dir, filename), efi_partition_path)

def delete_amdflash_files(efi_partition_path: str):
    """ Remove Amd flashing files from EFI partition """
    file_path = os.path.join(efi_partition_path, _amdflash_file)
    if os.path.exists(file_path):
        os.remove(file_path)

def delete_buff_files(efi_partition_path: str):
    """ Remove flashing files from EFI partition """
    for filename in _flashing_files:
        file_path = os.path.join(efi_partition_path, filename)
        if os.path.exists(file_path):
            os.remove(file_path)

def enable_bios_flash() -> bool:
    """ Change required settings to allow flash
        Unlock MPM and ME
        Disable FastBoot
        Disable Secure Boot
    Returns:
        True if a setting change requires reboot
    """
    DISABLE = "Disable"
    # Legacy Secure Boot value (pre-Camellia)
    LEGACY_DISABLE = "Legacy Support Disable and Secure Boot Disable"
    changed = False

    settings = BiosSettings()
    if settings[SettingNames.MPM] != "Unlock" or me_is_locked():
        hp_mpm.unlock_all()
        suppress_bios_messages()
        changed = True
    if settings[SettingNames.FASTBOOT] != DISABLE:
        settings[SettingNames.FASTBOOT] = DISABLE
        changed = True
    # Try new option for Camellia and later (non-legacy) 1st
    try:
        if settings[SettingNames.SECUREBOOT] != DISABLE:
            settings[SettingNames.SECUREBOOT] = DISABLE
            changed = True
    except KeyError:
        if settings[SettingNames.CONFIGURELEGACYSUPPORTSECUREBOOT] != LEGACY_DISABLE:
            settings[SettingNames.CONFIGURELEGACYSUPPORTSECUREBOOT] = LEGACY_DISABLE
            changed = True
    return changed

def get_flash_result(efi_partition_path: str) -> object:
    """ Get result from flash report file """
    efi_status = None
    flash_return = None

    file_path = os.path.join(efi_partition_path, "report.txt")
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            content = f.readlines()
        for line in content:
            line_breakup = line.split(":")
            if "EFI_STATUS" in line_breakup[0].strip():
                efi_status = line_breakup[1].strip()
            elif "Flash Return Code" in line_breakup[0].strip():
                flash_return = line_breakup[1].strip()
    return efi_status, flash_return

def suppress_bios_messages() -> bool:
    """ Issue test hook to simulate special key press during restart """
    SUPPRESSBIOSMESSAGESID = uuid.UUID("39B4E5C0-DA38-4810-821A-8B02C948C887")
    flag = 1
    return test_hooks.try_inject_data(SUPPRESSBIOSMESSAGESID, flag.to_bytes(1, 'little'))

def clear_suppress_bios_messages() -> bool:
    """ Clear test hook to simulate special key press during restart """
    SUPPRESSBIOSMESSAGESID = uuid.UUID("39B4E5C0-DA38-4810-821A-8B02C948C887")
    return test_hooks.clear_data(SUPPRESSBIOSMESSAGESID)

def me_is_locked() -> bool:
    """
    Check whether Intel ME Manufacturing Mode is open or closed
    Returns:
        True = closed
        False = open or unsupported (AMD)
    """
    return_code, data = test_hooks.extract_data(TEST_HOOK_ME_MODE, 1)
    if return_code == PrivateWmiReturnCodes.SUCCESS:
        return data[0] == 0
    if return_code < 0:
        return_code += 2**32
    if return_code != 0x8000000E:   # result on AMD, E_ILLEGAL_METHOD_CALL
        raise AssertionError("ME status test hook failed, return code: " + str(hex(return_code)))
    return False
