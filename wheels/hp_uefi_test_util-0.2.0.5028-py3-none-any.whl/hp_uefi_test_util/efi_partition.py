import logging
from subprocess import run, CalledProcessError


def mount_efi() -> bool:
    """ Checks if the letter is in use and mounts the drive"""
    check_mounted_drives = run(['wmic', 'LogicalDisk', 'GET', 'DeviceID'], capture_output=True)
    mounted_drives = check_mounted_drives.stdout.decode('utf-8')
    drive_list = (mounted_drives.strip().split('\r\r\n'))
    try:
        if not "Z:" in drive_list:
            run(['mountvol', 'z:', '/s'])
        else:
            unmount_efi()
            run(['mountvol', 'z:', '/s'])
        return True
    except CalledProcessError as e:
        logging.error(f"There was an error running the command {e}")
        return False


def unmount_efi() -> bool:
    """ unmount the drive"""
    try:
        run(['mountvol', 'z:', '/d'])
        return True
    except CalledProcessError as e:
        logging.error(f"There was an error running the command {e}")
        return False
