""" Test automation support for BIOS test hooks """
import logging
import uuid

from hp_wmi.private_wmi import *
from hp_wmi.private_wmi_defs import *

MAXBUFFERSIZE = 4096


@unique
class TestAutomationType(IntEnum):
    COMMAND_SUPPORT = 0
    DATA_INJECTION = 2
    DATA_EXTRACTION = 3
    GETVARBACKDOOR = 0x10
    SETVARBACKDOOR = 0x11


def is_supported() -> bool:
    """ See if BIOS supports test hooks
    Returns:
        True if supported
    """
    try:
        result, data = execute_private_wmi(PrivateWmiCommands.TESTHOOKS, TestAutomationType.COMMAND_SUPPORT,
                                           None, SizeOut.SIZE4)
        logging.debug(f"Test Automation support result: {result}")
        return result == PrivateWmiReturnCodes.SUCCESS
    except:
        logging.debug("Test Automation support exception")
        return False


def inject_data(guid: uuid.UUID, data_in: bytes or bytearray) -> int:
    """ Test automation data injection
    Args:
        guid: Test hook GUID ID
        data_in: Injected data
    Returns:
        Result code, 0 == success
    """
    if type(guid) != uuid.UUID:
        raise TypeError(type(guid))
    if type(data_in) != bytearray and type(data_in) != bytes:
        raise TypeError()

    data_size_in_bytes = bytearray(len(data_in).to_bytes(4, 'little'))
    in_buffer = bytearray(guid.bytes_le) + data_size_in_bytes + data_in
    result, _ = execute_private_wmi(PrivateWmiCommands.TESTHOOKS, TestAutomationType.DATA_INJECTION, in_buffer,
                                    SizeOut.SIZE0)
    logging.debug(f"Test Automation inject data result: {result}")
    return result


def clear_data(guid: uuid.UUID) -> int:
    """ Test automation clear data injection
    Args:
        guid: Test hook GUID ID
    Returns:
        Result code, 0 == success
    """
    return inject_data(guid, bytes([]))


def try_inject_data(guid: uuid.UUID, data_in) -> bool:
    """ Test automation data injection: only care about success
    Args:
        guid: Test hook GUID ID
        data_in: Injected data
    Returns:
        True on success
    """
    try:
        return inject_data(guid, data_in) == PrivateWmiReturnCodes.SUCCESS
    except:
        return False


def try_clear_data(guid: uuid.UUID) -> bool:
    """ Test automation clear data injection: only care about success
    Args:
        guid: Test hook GUID ID
        data_in: Injected data
    Returns:
        True on success
    """
    try:
        return clear_data(guid) == PrivateWmiReturnCodes.SUCCESS
    except:
        return False


def extract_data(guid: uuid.UUID, expected_data_size: int):
    """ Test automation data extraction
    Args:
        guid: Test hook GUID ID
        expected_data_size
    Returns:
        Result code, 0 == success
    """
    if type(guid) != uuid.UUID:
        raise TypeError(type(guid))
    if expected_data_size <= 0:
        raise ValueError("expected_data_size must be greater than 0")
    output_size = len(guid.bytes) + expected_data_size + 4  # 4 for size of uint32
    if output_size > MAXBUFFERSIZE:
        raise ValueError("expected_Data Data length too big for interface packet.")

    in_buffer = bytearray(guid.bytes_le) + expected_data_size.to_bytes(4, 'little')
    result, data_out = execute_private_wmi(PrivateWmiCommands.TESTHOOKS, TestAutomationType.DATA_EXTRACTION,
                                           in_buffer, output_size)
    logging.debug(f"Test Automation extract data result: {result}")
    return_data = None
    if result == PrivateWmiReturnCodes.SUCCESS:
        if guid != uuid.UUID(bytes_le=bytes(data_out[0:16])):
            raise Exception("Returned GUID is incorrect.")
        if int.from_bytes(data_out[16:20], 'little', signed=False) != expected_data_size:
            raise Exception("Received data size is wrong.")
        return_data = data_out[20:]

    return result, return_data
